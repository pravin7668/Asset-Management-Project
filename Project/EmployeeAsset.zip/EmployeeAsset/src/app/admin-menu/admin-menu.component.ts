import { Component, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { JwtService } from '../service/jwt.service';
@Component({
  selector: 'app-admin-menu',
  templateUrl: './admin-menu.component.html',
  styleUrl: './admin-menu.component.css',
})
export class AdminMenuComponent {
  adminName:string
  constructor(private _router:Router){
    this.adminName=localStorage.getItem("name")

  }
  
  logout(){
    localStorage.removeItem("id")
    localStorage.removeItem('token')
    this._router.navigate([''])
  }
  
  
}
