import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class JwtService {
  decodedToken:any
  token:string
  constructor() { }
  decodeToken(){
    this.token=localStorage.getItem('token')
    this.decodedToken=decodeToken(this.token)
    return this.decodedToken
  }

  isLoggedIn():boolean{
    this.token=localStorage.getItem('token')
    this.decodedToken=decodeToken(this.token)
    console.log("Auth working")
     if (!this.decodedToken) {
      return false;
    }
    const now = Date.now().valueOf() /1000;
    console.log("now :"+now)
    console.log("exp :"+this.decodedToken.exp)
    return this.decodedToken.exp > now;
  }
  role():string{
    this.token=localStorage.getItem('token')
    this.decodedToken=decodeToken(this.token)
    if(this.isLoggedIn()){
      console.log(this.decodedToken.role)
      return this.decodedToken.role
    }else{
      return "expired"
    }
  }

}

export function decodeToken(token: string): any {
  if (!token) {
    return null;
  }

  // Split the token into its parts
  const parts = token.split('.');

  if (parts.length !== 3) {
    throw new Error('The token is not valid');
  }

  // Decode the Base64 URL encoded string
  const decodeBase64Url = (base64Url: string): string => {
    let base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    while (base64.length % 4) {
      base64 += '=';
    }
    return decodeURIComponent(
      atob(base64)
        .split('')
        .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
  };

  // Decode the payload
  const decodedPayload = decodeBase64Url(parts[1]);

  // Parse the JSON string
  return JSON.parse(decodedPayload);

}