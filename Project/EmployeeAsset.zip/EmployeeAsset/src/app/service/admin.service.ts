import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { LoginDto } from '../class/login-dto';
import { User } from '../class/user';
import { Asset } from '../class/asset';
import { SearchAssetAllocatedToUser } from '../class/search-asset-allocated-to-user';
import { SearchAssetDto } from '../class/search-asset-dto';
import { Admin } from '../class/admin';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private _http:HttpClient) { }

  findByEmail(email:string):Observable<any>{
    return this._http.get("http://localhost:8184/auth/findUserByEmail/"+email)
  }

  findAdminById1(adminId:number):Observable<any>{
    return this._http.get("http://localhost:8184/auth/findAdminById/"+adminId)
  }

  findAdminById(id:number,token:string):Observable<any>{
    var headers_object = new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token,
  
    });
    const httpOptions = {
      headers : headers_object,
      responseType: 'text' as 'json'
    }
    return this._http.get("http://localhost:8184/admin/findAdminById/"+id,httpOptions)
  }

  addAdmin(user:User):Observable<any>{
    return this._http.post("http://localhost:8184/admin/addAdmin",user,{responseType:'text'})
  }

  updateAdmin(user:Admin,token:string){
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.put("http://localhost:8184/admin/updateAdmin",user,httpOptions)
  }

  loginAdmin(loginDto:LoginDto):Observable<any>{
    return this._http.post("http://localhost:8184/admin/loginAdmin",loginDto,{responseType:'text'}).pipe(
      tap((resp) => {
        // alert(resp);
      })
    )
  }

  showAsset(token:string):Observable<any>{
    var headers_object = new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token,
  
    });
   
    const httpOptions = {
      headers : headers_object
    }
    return this._http.get("http://localhost:8184/admin/showAsset",httpOptions)
  }

  addAsset(asset:Asset,token:string):Observable<any>{
    var headers_object = new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token,
  
    });
   
    const httpOptions = {
      headers : headers_object,
      responseType:'text' as 'json'
    }
    return this._http.post("http://localhost:8184/admin/addAsset",asset,httpOptions)
  }

  updateAsset(updatedAsset:Asset,token:string):Observable<any>{
    var headers_object = new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token,
  
    });
   
    const httpOptions = {
      headers : headers_object,
      responseType:'text' as 'json'
    }
    return this._http.put("http://localhost:8184/admin/updateAsset",updatedAsset,httpOptions)
  }

  deleteAsset(assetId:number,token:string):Observable<any>{
    var headers_object = new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token,
  
    });
   
    const httpOptions = {
      headers : headers_object,
      responseType:'text' as 'json'

    }
    return this._http.delete("http://localhost:8184/admin/deleteAsset/"+assetId,httpOptions)
  }

  showAvailableAsset(token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.get("http://localhost:8184/admin/showAvailableAsset",httpOptions)
  }

  showPendingAssetRequest(token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
   return this._http.get("http://localhost:8184/admin/showAssetAllocationRequest",httpOptions)

  }

  approvePendingAssetRequest(adminId:number,requestId:number,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
    const httpOptions = {
      headers : header_objects,
      responseType:'text' as 'json'

   }
   return this._http.post("http://localhost:8184/admin/approveAssetRequest/"+adminId+"/"+requestId,{},httpOptions)
  }


  showPendingServiceRequest(token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
    const httpOptions = {
      headers : header_objects
   }
   return this._http.get("http://localhost:8184/admin/showAssetServiceRequest",httpOptions)
  }


  approveAssetServiceRequest(adminId:number,serviceId:number,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
    const httpOptions = {
      headers : header_objects,
      responseType:'text' as 'json'

   }
   return this._http.post("http://localhost:8184/admin/approveAssetServiceRequest/"+adminId+"/"+serviceId,{},httpOptions)
  }

  showPendingReturnRequest(token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
    const httpOptions = {
      headers : header_objects
   }
   return this._http.get("http://localhost:8184/admin/showAssetReturnRequest",httpOptions)
  }

  approvePendingReturnRequest(requestId:number,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
    const httpOptions = {
      headers : header_objects,
      responseType:'text' as 'json'

   }
   return this._http.post("http://localhost:8184/admin/approveAssetReturnRequest/"+requestId,{},httpOptions)

  }


  showAssetAllocatedToUser(token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.get("http://localhost:8184/admin/showAssetAllocatedToUser",httpOptions)
  }

  searchshowAssetAllocatedToUserById(input:SearchAssetAllocatedToUser,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.post("http://localhost:8184/admin/searchshowAssetAllocatedToUserById",input,httpOptions)
  }

  searchshowAssetAllocatedToUserByNameAndEmail(input:SearchAssetAllocatedToUser,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.post("http://localhost:8184/admin/searchshowAssetAllocatedToUserByNameAndEmail",input,httpOptions)
  }



  getAssetCategory(token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
   return this._http.get("http://localhost:8184/admin/getAssetCategories",httpOptions)

  }

  sendAuditRequest(requestId:number,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
    

    const httpOptions = {
      headers : header_objects,
      responseType:'text' as 'json'

   }
   return this._http.post("http://localhost:8184/admin/sendAuditRequest/"+requestId,{},httpOptions)
  }

  showPendingAuditRequest(token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
    

    const httpOptions = {
      headers : header_objects
   }
   return this._http.get("http://localhost:8184/admin/showPendingAuditRequest",httpOptions)
  }

  verifyAuditRequest(requestId:number,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
    
    const httpOptions = {
      headers : header_objects,
      responseType:'text' as 'json'

   }
   return this._http.post("http://localhost:8184/admin/verifyAuditRequest/"+requestId,{},httpOptions)
  }




  searchAssetAllocationRequestByUserId(input:SearchAssetAllocatedToUser,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.post("http://localhost:8184/admin/searchAssetAllocationRequestByUserId",input,httpOptions)
  }

  searchAssetAllocationRequestByNameAndEmail(input:SearchAssetAllocatedToUser,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.post("http://localhost:8184/admin/searchAssetAllocationRequestByNameAndEmail",input,httpOptions)
  }

  searchAssetServiceRequestByUserId(input:SearchAssetAllocatedToUser,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.post("http://localhost:8184/admin/searchAssetServiceRequestByUserId",input,httpOptions)
  }

  searchAssetServiceRequestByNameAndEmail(input:SearchAssetAllocatedToUser,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.post("http://localhost:8184/admin/searchAssetServiceRequestByNameAndEmail",input,httpOptions)
  }

  searchReturnRequestByUserId(input:SearchAssetAllocatedToUser,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.post("http://localhost:8184/admin/searchReturnRequestByUserId",input,httpOptions)
  }

  searchReturnRequestByNameAndEmail(input:SearchAssetAllocatedToUser,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.post("http://localhost:8184/admin/searchReturnRequestByNameAndEmail",input,httpOptions)
  }

  searchAuditRequestByUserId(input:SearchAssetAllocatedToUser,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.post("http://localhost:8184/admin/searchAuditRequestByUserId",input,httpOptions)
  }

  searchAuditRequestByNameAndEmail(input:SearchAssetAllocatedToUser,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.post("http://localhost:8184/admin/searchAuditRequestByNameAndEmail",input,httpOptions)
  }

  searchAllAssetByNameAndCategory(searchAssetDto:SearchAssetDto,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
   return this._http.post("http://localhost:8184/admin/searchAllAssetByNameAndCategory",searchAssetDto ,httpOptions)
  }

  searchAllAssetByNameOrCategory(searchAssetDto:SearchAssetDto,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
   return this._http.post("http://localhost:8184/admin/searchAllAssetByNameOrCategory",searchAssetDto,httpOptions)
  }

  searchAssetByNameAndCategory(searchAssetDto:SearchAssetDto,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
   return this._http.post("http://localhost:8184/admin/searchAssetByNameAndCategory",searchAssetDto ,httpOptions)
  }

  searchAssetByNameOrCategory(searchAssetDto:SearchAssetDto,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
   return this._http.post("http://localhost:8184/admin/searchAssetByNameOrCategory",searchAssetDto,httpOptions)
  }


}
