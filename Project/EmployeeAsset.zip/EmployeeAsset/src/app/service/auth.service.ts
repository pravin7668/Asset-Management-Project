import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MailHeaders } from '../class/mail-headers';
import { HttpClient } from '@angular/common/http';
import { ForgotPasswordDto } from '../class/forgot-password-dto';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  token:string

  constructor(private _http:HttpClient) { }
  sendMail(mailHeaders:MailHeaders):Observable<any>{
    return this._http.post("http://localhost:8184/auth/sendMail",mailHeaders,{ responseType: 'text' })
  }

  forgotPasswordAdmin(forgotPasswordDto:ForgotPasswordDto):Observable<any>{
    return this._http.post("http://localhost:8184/auth/forgotPasswordAdmin",forgotPasswordDto,{ responseType: 'text' })
  }

  forgotPasswordUser(forgotPasswordDto:ForgotPasswordDto):Observable<any>{
    return this._http.post("http://localhost:8184/auth/forgotPasswordUser",forgotPasswordDto,{ responseType: 'text' })
  }
}



