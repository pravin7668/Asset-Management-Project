import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { User } from '../class/user';
import { LoginDto } from '../class/login-dto';
import { ServiceRequestDto } from '../class/service-request-dto';
import { SearchAssetDto } from '../class/search-asset-dto';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  url:string

  constructor(private _http:HttpClient) { }
  
  findByEmail(email:string):Observable<any>{
    return this._http.get("http://localhost:8184/auth/findUserByEmail/"+email)
  }

  showUser():Observable<any>{
    return this._http.get("http://localhost:8184/user/showAll")
  }

  findUserById1(userId:number):Observable<any>{
    return this._http.get("http://localhost:8184/auth/findUserById/"+userId)
  }

  searchUserById(id:number):Observable<any>{
    return this._http.get("http://localhost:8184/user/findUserById/"+id)
  }

  addUser(user:User):Observable<any>{
    return this._http.post("http://localhost:8184/user/addUser",user)
  }

  updateUser(user:User,token:string){
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.put("http://localhost:8184/user/updateUser",user,httpOptions)
  }

  loginUser(logindto:LoginDto):Observable<any>{
    return this._http.post("http://localhost:8184/user/loginUser",logindto,{responseType:'text'}).pipe(
      tap((resp) => {
        // alert(resp);
      }))
  }

  showAvailableAsset(token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.get("http://localhost:8184/user/showAvailableAsset",httpOptions)
  }

  requestAsset(userId:number,assetId:number,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects,
      responseType:'text' as 'json'

   }
   return this._http.post("http://localhost:8184/user/requestAsset/"+userId+"/"+assetId,{},httpOptions)
  }


  assetRequestStatus(id:number,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
    return this._http.get("http://localhost:8184/user/assetRequestStatus/"+id,httpOptions)
  }

  findUserById(id:number,token:string):Observable<any>{
    var header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    })
    const httpOptions = {
      headers : header_objects
    }
      return this._http.get("http://localhost:8184/user/findUserById/"+id,httpOptions)
  }


  myAssets(id:number,token:string):Observable<any>{
    var header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    })
    const httpOptions = {
      headers : header_objects
    }
    console.log("ID"+id)
    return this._http.get("http://localhost:8184/user/myAssets/"+id,httpOptions)
  }
   
  serviceRequest(serviceRequest:ServiceRequestDto,token:string):Observable<any>{
    var header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    })
    const httpOptions = {
      headers : header_objects,
      responseType:'text' as 'json'

    }
    return this._http.post("http://localhost:8184/user/assetServiceRequest",serviceRequest,httpOptions)

  }

  serviceRequestStatus(userId:number,token:string):Observable<any>{
    var header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    })
    const httpOptions = {
      headers : header_objects
    }
    return this._http.get("http://localhost:8184/user/serviceRequestStatus/"+userId,httpOptions)

  }

  assetReturnRequest(requestId:number,token:string):Observable<any>{
    var header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    })
    const httpOptions = {
      headers : header_objects,
      responseType:'text' as 'json'

    }
    return this._http.post("http://localhost:8184/user/assetReturnRequest/"+requestId,{},httpOptions)

  }


  assetHistory(id:number,token:string):Observable<any>{
    var header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    })
    const httpOptions = {
      headers : header_objects
    }
    return this._http.get("http://localhost:8184/user/assetHistory/"+id,httpOptions)
  }

  showAuditRequest(token:string,id:number):Observable<any>{
    var header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    })
    const httpOptions = {
      headers : header_objects
    }
    return this._http.get("http://localhost:8184/user/showAuditRequest/"+id,httpOptions)

  }

  noOfPendingAssetRequest(userId:number,token:string):Observable<any>{
    var header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    })
    const httpOptions = {
      headers : header_objects
    }
    return this._http.get("http://localhost:8184/user/noOfPendingAssetRequest/"+userId,httpOptions)

  }

  noOfServiceRequest(userId:number,token:string):Observable<any>{
    var header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    })
    const httpOptions = {
      headers : header_objects
    }
    return this._http.get("http://localhost:8184/user/noOfServiceRequest/"+userId,httpOptions)

  }

  noOfAuditRequest(userId:number,token:string):Observable<any>{
    var header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    })
    const httpOptions = {
      headers : header_objects
    }
    return this._http.get("http://localhost:8184/user/noOfAuditRequest/"+userId,httpOptions)

  }

  getAssetCategory(token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
   return this._http.get("http://localhost:8184/user/getAssetCategories",httpOptions)

  }

  searchAssetByNameAndCategory(searchAssetDto:SearchAssetDto,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
   return this._http.post("http://localhost:8184/user/searchAssetByNameAndCategory",searchAssetDto ,httpOptions)
  }

  searchAssetByNameOrCategory(searchAssetDto:SearchAssetDto,token:string):Observable<any>{
    let header_objects=new HttpHeaders({
      "Content-Type":"application/json",
      "Authorization":"Bearer "+token
    });
  
    const httpOptions = {
      headers : header_objects
   }
   return this._http.post("http://localhost:8184/user/searchAssetByNameOrCategory",searchAssetDto,httpOptions)
  }
}

