import { Component, ViewChild } from '@angular/core';
import { AssetServiceRequestDto } from '../../class/asset-service-request-dto';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { UserService } from '../../service/user.service';

@Component({
  selector: 'app-service-request-status',
  templateUrl: './service-request-status.component.html',
  styleUrl: './service-request-status.component.css'
})
export class ServiceRequestStatusComponent {
  displayedColumns:string[]=[
    'userId',
    'firstName',
    'assetId',
    'assetName',
    'serviceType',
    'description',
    'status'
  ]
  assetServiceRequestDto:AssetServiceRequestDto[]
  id:number
  noData:boolean
  dataSource=new MatTableDataSource<AssetServiceRequestDto>
  token:string
  @ViewChild(MatSort) sort={} as MatSort
  @ViewChild(MatPaginator) paginator={} as MatPaginator
  constructor(private _userService:UserService){
    this.noData=false
    this.id=parseInt(localStorage.getItem("id"))
    this.token=localStorage.getItem("token")
    this._userService.serviceRequestStatus(this.id,this.token).subscribe(x=>{
      this.assetServiceRequestDto=x
      if(this.assetServiceRequestDto.length==0){
        this.noData=true
      }
      this.dataSource=new MatTableDataSource(this.assetServiceRequestDto)
        this.dataSource.paginator=this.paginator
        this.dataSource.sort=this.sort
    })
  }
}
