import { Component } from '@angular/core';

@Component({
  selector: 'app-return-asset',
  templateUrl: './return-asset.component.html',
  styleUrl: './return-asset.component.css'
})
export class ReturnAssetComponent {

}
