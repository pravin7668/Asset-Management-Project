import { Component, EventEmitter, Input, input, Output } from '@angular/core';
import { AllocatedAssetDto } from '../../class/allocated-asset-dto';

@Component({
  selector: 'app-asset-card',
  templateUrl: './asset-card.component.html',
  styleUrl: './asset-card.component.css'
})
export class AssetCardComponent {
    @Input() asset !:AllocatedAssetDto
    @Output() serviceClicked = new EventEmitter<AllocatedAssetDto>();
    @Output() returnClicked = new EventEmitter<AllocatedAssetDto>();

    onServiceClick(){
      this.serviceClicked.emit(this.asset)
    }
    onReturnClick(){
      this.returnClicked.emit(this.asset)
    }
    

}
