import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestAssetCardComponent } from './request-asset-card.component';

describe('RequestAssetCardComponent', () => {
  let component: RequestAssetCardComponent;
  let fixture: ComponentFixture<RequestAssetCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RequestAssetCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RequestAssetCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
