import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Asset } from '../../class/asset';

@Component({
  selector: 'app-request-asset-card',
  templateUrl: './request-asset-card.component.html',
  styleUrl: './request-asset-card.component.css'
})
export class RequestAssetCardComponent {
  @Input()  asset!:Asset
  @Output() returnClicked = new EventEmitter<Asset>();

  onRequestClick(){
    this.returnClicked.emit(this.asset)
  }
  
}
