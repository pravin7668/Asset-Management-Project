import { Component, Input } from '@angular/core';
import { AssetHistoryDto } from '../../class/asset-history-dto';

@Component({
  selector: 'app-user-asset-history-card',
  templateUrl: './user-asset-history-card.component.html',
  styleUrl: './user-asset-history-card.component.css'
})
export class UserAssetHistoryCardComponent {
  @Input() asset !:AssetHistoryDto
}
