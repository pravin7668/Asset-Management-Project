import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAssetHistoryCardComponent } from './user-asset-history-card.component';

describe('UserAssetHistoryCardComponent', () => {
  let component: UserAssetHistoryCardComponent;
  let fixture: ComponentFixture<UserAssetHistoryCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UserAssetHistoryCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserAssetHistoryCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
