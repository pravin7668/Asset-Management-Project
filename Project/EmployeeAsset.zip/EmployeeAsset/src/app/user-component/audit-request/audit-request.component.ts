import { Component, ViewChild } from '@angular/core';
import { AllocatedAssetDto } from '../../class/allocated-asset-dto';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { AdminService } from '../../service/admin.service';
import { UserService } from '../../service/user.service';

@Component({
  selector: 'app-audit-request',
  templateUrl: './audit-request.component.html',
  styleUrl: './audit-request.component.css'
})
export class AuditRequestComponent {
  displayedColumns:string[]=[
    'assetId',
    'assetName',
    'userId',
    'firstName',
    'issuedDate',
    'auditStatus'
  ]
  userAssets:AllocatedAssetDto[]
  token:string
  id:number
  noData:boolean
  dataSource=new MatTableDataSource<AllocatedAssetDto>
  @ViewChild(MatSort) sort={} as MatSort
  @ViewChild(MatPaginator) paginator={} as MatPaginator
  constructor(private _userService:UserService){
    this.noData=false
    this.token=localStorage.getItem("token")
    this.id= parseInt(localStorage.getItem("id"))
    this._userService.showAuditRequest(this.token,this.id).subscribe(x=>{
      this.userAssets=x
      if(this.userAssets.length==0){
        this.noData=true
      }
      this.dataSource=new MatTableDataSource(this.userAssets)
      this.dataSource.paginator=this.paginator
      this.dataSource.sort=this.sort
    })
  }
}
