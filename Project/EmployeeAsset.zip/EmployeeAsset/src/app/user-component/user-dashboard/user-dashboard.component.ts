import { Component } from '@angular/core';
import { UserService } from '../../service/user.service';
import { AllocatedAssetDto } from '../../class/allocated-asset-dto';
import { AssetServiceRequestDto } from '../../class/asset-service-request-dto';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrl: './user-dashboard.component.css'
})
export class UserDashboardComponent {
  id:number
  token:string
  myAssets:AllocatedAssetDto[]
  service:AssetServiceRequestDto[]
  noOfmyAssets:number
  noOfpendingServiceRequest:number
  noOfpendingAssetRequest:number
  noOfpendingAuditRequest:number

  constructor(private _userService:UserService,private _activatedRoute:ActivatedRoute,private _router:Router){
    this.id=parseInt(localStorage.getItem("id"))
    this.token=localStorage.getItem("token")

}
  ngOnInit(){
    this._userService.myAssets(this.id,this.token).subscribe(x=>{
      this.myAssets=x
      this.noOfmyAssets=this.myAssets.length
    })
    this._userService.noOfPendingAssetRequest(this.id,this.token).subscribe(x=>{
    this.myAssets=x
    this.noOfpendingAssetRequest=this.myAssets.length
    })
  this._userService.noOfServiceRequest(this.id,this.token).subscribe(x=>{
    this.service=x
    this.noOfpendingServiceRequest=this.service.length
    })
  this._userService.noOfAuditRequest(this.id,this.token).subscribe(x=>{
    this.myAssets=x
    this.noOfpendingAuditRequest=this.myAssets.length
    })
  }

}
