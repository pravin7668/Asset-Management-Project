import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetCardContainerComponent } from './asset-card-container.component';

describe('AssetCardContainerComponent', () => {
  let component: AssetCardContainerComponent;
  let fixture: ComponentFixture<AssetCardContainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AssetCardContainerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetCardContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
