import { Component } from '@angular/core';
import { UserService } from '../../service/user.service';
import { AllocatedAssetDto } from '../../class/allocated-asset-dto';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-asset-card-container',
  templateUrl: './asset-card-container.component.html',
  styleUrl: './asset-card-container.component.css'
})
export class AssetCardContainerComponent {
  myAssets:AllocatedAssetDto[]
  id:number
  noData:boolean
  token:string
    constructor(private _userService:UserService,private _router:Router,private _toastr:ToastrService){
      this.noData=false
      this.id=parseInt(localStorage.getItem("id"))
      this.token=localStorage.getItem("token")
      this._userService.myAssets(this.id,this.token).subscribe(x=>{
        this.myAssets=x
        if(this.myAssets.length==0){
          this.noData=true
        }
      })
    }

  handleService(requestId:number){
    this._router.navigate(['/user-menu',{outlets:{'hexa':['service-request']}}],{queryParams:{
        requestId:requestId
    }})
  }

  res:string
  handleReturn(requestId:number){
      this._userService.assetReturnRequest(requestId,this.token).subscribe(x=>{
          this.res=x
          this._toastr.success(this.res,'Success')
          this._userService.myAssets(this.id,this.token).subscribe(x=>{
            this.myAssets=x
            if(this.myAssets.length==0){
              this.noData=true
            }
          })
          
      })
  }
}
