import { Component, ViewChild } from '@angular/core';
import { AllocatedAssetDto } from '../../class/allocated-asset-dto';
import { UserService } from '../../service/user.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-user-assets',
  templateUrl: './user-assets.component.html',
  styleUrl: './user-assets.component.css'
})
export class UserAssetsComponent {
    myAssets:AllocatedAssetDto[]
    displayedColumns:string[]=[
      'assetId',
      'assetName',
      'userId',
      'firstName',
      'issuedDate',
      'serviceButton',
      'returnButton'
    ]
    id:number
    noData:boolean
    token:string
    dataSource=new MatTableDataSource<AllocatedAssetDto>
    @ViewChild(MatSort) sort={} as MatSort
    @ViewChild(MatPaginator) paginator={} as MatPaginator
    constructor(private _userService:UserService,private _router:Router,private _toastr:ToastrService){
      this.noData=false
      this.id=parseInt(localStorage.getItem("id"))
      this.token=localStorage.getItem("token")
      this._userService.myAssets(this.id,this.token).subscribe(x=>{
        this.myAssets=x
        if(this.myAssets.length==0){
          this.noData=true
        }
        this.dataSource=new MatTableDataSource(this.myAssets)
        this.dataSource.paginator=this.paginator
        this.dataSource.sort=this.sort
      })
    }
    handleService(requestId:number){
        this._router.navigate(['/user-menu',{outlets:{'hexa':['service-request']}}],{queryParams:{
          requestId:requestId
        }})
    }
    
    res:string
    handleReturn(requestId:number){
        this._userService.assetReturnRequest(requestId,this.token).subscribe(x=>{
            this.res=x
            this._toastr.success(this.res,'Success')
            this._userService.myAssets(this.id,this.token).subscribe(x=>{
              this.myAssets=x
              if(this.myAssets.length==0){
                this.noData=true
              }
              this.dataSource=new MatTableDataSource(this.myAssets)
              this.dataSource.paginator=this.paginator
              this.dataSource.sort=this.sort
            })
            
        })
    }

}
