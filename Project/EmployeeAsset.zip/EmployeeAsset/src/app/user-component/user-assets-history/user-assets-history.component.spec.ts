import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAssetsHistoryComponent } from './user-assets-history.component';

describe('UserAssetsHistoryComponent', () => {
  let component: UserAssetsHistoryComponent;
  let fixture: ComponentFixture<UserAssetsHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UserAssetsHistoryComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserAssetsHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
