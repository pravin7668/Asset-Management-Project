import { Component, ViewChild } from '@angular/core';
import { AssetHistoryDto } from '../../class/asset-history-dto';
import { UserService } from '../../service/user.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-user-assets-history',
  templateUrl: './user-assets-history.component.html',
  styleUrl: './user-assets-history.component.css'
})
export class UserAssetsHistoryComponent {
  id:number
  noData:boolean
  assetHistory:AssetHistoryDto[]
  displayedColumns:string[]=[
    'assetName',
    'assetCategory',
    'issuedDate',
    'returnedDate',
    'status'
  ]

  dataSource=new MatTableDataSource<AssetHistoryDto>
  token:string
  @ViewChild(MatSort) sort={} as MatSort
  @ViewChild(MatPaginator) paginator={} as MatPaginator
  constructor(private _userService:UserService){
    this.noData=false
    this.id=parseInt(localStorage.getItem("id"))
    this.token=localStorage.getItem("token")
    this._userService.assetHistory(this.id,this.token).subscribe(x=>{
      this.assetHistory=x
      if(this.assetHistory.length==0){
        this.noData=true
      }
      this.dataSource=new MatTableDataSource(this.assetHistory)
        this.dataSource.paginator=this.paginator
        this.dataSource.sort=this.sort
    })
  }
}
