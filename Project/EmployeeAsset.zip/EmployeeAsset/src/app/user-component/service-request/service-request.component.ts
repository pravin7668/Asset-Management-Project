import { Component } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { UserService } from '../../service/user.service';
import { ServiceRequestDto } from '../../class/service-request-dto';
import { ToastrService } from 'ngx-toastr';




@Component({
  selector: 'app-service-request',
  templateUrl: './service-request.component.html',
  styleUrl: './service-request.component.css'
})
export class ServiceRequestComponent {
  requestId:number
  serviceRequest:ServiceRequestDto
  constructor(private _userService:UserService ,private _route:ActivatedRoute,private _router:Router,private _toastr:ToastrService){
      this.serviceRequest=new ServiceRequestDto()
  }
  selected: string
  description:string
  token:string

  options: { value: string, viewValue: string }[] = [
    { value: 'Malfunction', viewValue: 'Malfunction' },
    { value: 'Repair', viewValue: 'Repair' },
    { value: 'Lost', viewValue: 'Lost' }
  ];
  ngOnInit():void{
      this._route.queryParams.subscribe(params=>{
        this.requestId=params['requestId']
      })
  }
  res:string
  handleService(){
    this.serviceRequest.requestId=this.requestId
    this.serviceRequest.serviceType=this.selected
    this.serviceRequest.description=this.description
    this.token=localStorage.getItem("token")
    this._userService.serviceRequest(this.serviceRequest,this.token).subscribe(x=>{
      this.res=x
      this._toastr.success(this.res,'Success')
    })
    this._router.navigate(['/user-menu',{outlets:{'hexa':['user-assets']}}])

  }

  // handleService(){
  //   this._toastr.success("Service Request Sent",'Success')
  // }

}
