import { Component } from '@angular/core';
import { UserService } from '../../service/user.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { User } from '../../class/user';
import { Login } from '../../class/login';
import { LoginDto } from '../../class/login-dto';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
import { UserForgotPasswordComponent } from '../user-forgot-password/user-forgot-password.component';
import { UserSignupComponent } from '../user-signup/user-signup.component';

@Component({
  selector: 'app-login',
  templateUrl: './user.login.component.html',
  styleUrl: './user.login.component.css'
})
export class UserLoginComponent {
  email:string
  password:string
  isValid:boolean
  credentials:Login
  token:string
  userId:number
  loginDto:LoginDto
  loginForm:FormGroup
  user:User
  userName:string

  constructor(private _userService:UserService,private _router:Router,private _formBuilder:FormBuilder,private _toastr:ToastrService,private _dialog:MatDialog){
    this.isValid=false
    this.loginDto=new LoginDto()
  }

  ngOnInit(){
    this.loginForm=this._formBuilder.group({
      'email':['',[Validators.required,Validators.email]],
      'password':['',Validators.required]
    })

    this.loginForm.get('email').statusChanges.subscribe(value=>{
      if(value=="VALID"){
        console.log(this.loginForm.get('email').value)
        this._userService.findByEmail(this.loginForm.get('email').value).subscribe(xx=>{
          this.credentials=xx
          if(this.credentials!=null){
            this.userId=this.credentials.userId
            localStorage.setItem("id",this.credentials.userId.toString())
            this._userService.findUserById1(this.userId).subscribe(xxx=>{
                this.user=xxx
                this.userName=this.user.firstName
                localStorage.setItem("name",this.userName)
                console.log(this.userName)
            })
          }
        })
      }
    })
  }




  handleClick(){
    const _dialogRef= this._dialog.open(UserSignupComponent,{
      width:'800px',
      height:'100vh'
   })
    // this._router.navigate(['user-signup'])
  }
  handleLogin():void{
    if(this.loginForm.valid){

      this.loginDto.email=this.loginForm.get('email').value
      this.loginDto.password=this.loginForm.get('password').value
      this._userService.loginUser(this.loginDto).subscribe(x=>{
          this.token=x
          localStorage.setItem("token",this.token)
          this._router.navigate(['/user-menu',{outlets:{'hexa':['user-dashboard']}}])
      })
    }
    else{
      this._toastr.error("Please Fill the Required Field","Error")
      this.loginForm.markAllAsTouched()
    }

  }
  handleForgotPassword(){
     const _dialogRef= this._dialog.open(UserForgotPasswordComponent,{
        width:'800px',
        height:'500px'
     })
    // this._router.navigate(['user-forgot-password'])
  }
}
