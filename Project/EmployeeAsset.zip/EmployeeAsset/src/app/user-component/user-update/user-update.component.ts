import { Component, Inject } from '@angular/core';
import { User } from '../../class/user';
import { MailHeaders } from '../../class/mail-headers';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { UserService } from '../../service/user.service';
import { AuthService } from '../../service/auth.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-user-update',
  templateUrl: './user-update.component.html',
  styleUrl: './user-update.component.css'
})
export class UserUpdateComponent {
    
  user:User
  passwordStrength:number=0
  otp:string
  userEnteredOtp:string
  otpInput:boolean
  otpButton:boolean
  isOtpValid:boolean
  isEmailVerified:boolean
  mailHeaders:MailHeaders
  signUpForm:FormGroup
  token:string

  constructor(private _userService:UserService,private _authService:AuthService,private _formBuilder:FormBuilder,private _router:Router,private _toastr:ToastrService,
    private _dialogRef:MatDialogRef<UserUpdateComponent>,    @Inject(MAT_DIALOG_DATA) public userUpdate:User

  ){
    this.otpInput=false
    this.mailHeaders=new MailHeaders()
    this.user=new User()
    this.token=localStorage.getItem("token")
  }
  ngOnInit():void{
    this.signUpForm=this._formBuilder.group({
      'firstName':[this.userUpdate.firstName,Validators.required],
      'lastName':[this.userUpdate.lastName,Validators.required],
      'address':[this.userUpdate.address,Validators.required],
      'phoneno':[this.userUpdate.phoneno,[Validators.required,this.phonenoValidator()]],
      'email':[this.userUpdate.email,[Validators.required,Validators.email]],  
    })

    this.signUpForm.get('email')?.statusChanges.subscribe(status=>{
      if(this.signUpForm.get('email').dirty){
        this.isEmailVerified=false
        this.otpButton=true
      }
    })

    this.signUpForm.get('otp').valueChanges.subscribe(val=>{
      if(this.signUpForm.get('otp').dirty){
        this.isOtpValid=false
      }
    })

  }

  phonenoValidator():ValidatorFn {
    return (control:AbstractControl):ValidationErrors | null =>{
    const phoneno=control.value
    const err:ValidationErrors={}
    if(/[a-z]+/.test(phoneno) || /[A-Z]+/.test(phoneno)){
      err['hasCharacters']=true
    }
    if(phoneno.length>10){
      err['hasMoreNumber']=true
    }
    if(phoneno.length<10){
      err['hasLessNumber']=true
    }
    return Object.keys(err).length>0?err:null
  }
}

 
  
  

  
  handleUpdate():void{
    if(this.signUpForm.valid){
        console.log("Form Submitted",this.signUpForm.value)
        this.user=this.signUpForm.value
        this.user.status="Active"
        this.user.userId=this.userUpdate.userId
        this.user.password=this.userUpdate.password
        console.log(this.user)
        this._userService.updateUser(this.user,this.token).subscribe(x=>{
          this._toastr.success("User Updated Successfully","Success")
          this._dialogRef.close()
        })


      }
    else{
      this._toastr.error("Please Fill the Required Field","Error")
        this.signUpForm.markAllAsTouched()
    }
          //   this._toastr.success("User Added Successfully","Success")
          // this._dialogRef.close()
  }

 
}

