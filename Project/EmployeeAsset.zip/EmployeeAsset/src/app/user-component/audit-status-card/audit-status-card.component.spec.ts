import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AuditStatusCardComponent } from './audit-status-card.component';

describe('AuditStatusCardComponent', () => {
  let component: AuditStatusCardComponent;
  let fixture: ComponentFixture<AuditStatusCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AuditStatusCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AuditStatusCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
