import { Component, Input } from '@angular/core';
import { AllocatedAssetDto } from '../../class/allocated-asset-dto';

@Component({
  selector: 'app-audit-status-card',
  templateUrl: './audit-status-card.component.html',
  styleUrl: './audit-status-card.component.css'
})
export class AuditStatusCardComponent {
    @Input() asset:AllocatedAssetDto
}
