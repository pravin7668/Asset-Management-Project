import { Component, Input } from '@angular/core';
import { AllocatedAssetDto } from '../../class/allocated-asset-dto';

@Component({
  selector: 'app-asset-request-status-card',
  templateUrl: './asset-request-status-card.component.html',
  styleUrl: './asset-request-status-card.component.css'
})
export class AssetRequestStatusCardComponent {
  @Input() asset !:AllocatedAssetDto

}
