import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetRequestStatusCardComponent } from './asset-request-status-card.component';

describe('AssetRequestStatusCardComponent', () => {
  let component: AssetRequestStatusCardComponent;
  let fixture: ComponentFixture<AssetRequestStatusCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AssetRequestStatusCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetRequestStatusCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
