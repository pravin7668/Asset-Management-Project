import { Component, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Asset } from '../../class/asset';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { UserService } from '../../service/user.service';
import { SearchAssetDto } from '../../class/search-asset-dto';
import { ToastrService } from 'ngx-toastr';




@Component({
  selector: 'app-request-asset',
  templateUrl: './request-asset.component.html',
  styleUrl: './request-asset.component.css'
})
export class RequestAssetComponent {
  displayedColumns: string[] = [
    'assetId',
    'assetName',
    'assetCategory',
    'assetDescription',
    'manufacturingDate',
    'expiryDate',
    'request'
  ];

  token:string
  userId:number
  searchAssetDto:SearchAssetDto
  assetSearch:string
  selectedCategory:string
  categoryOptions:string[]
  assets:Asset[]
    dataSource=new MatTableDataSource<Asset>
    @ViewChild(MatSort) sort = {} as MatSort;
    @ViewChild(MatPaginator) paginator = {} as MatPaginator;
  constructor(private _userService:UserService,private _toastr:ToastrService){
      this.searchAssetDto=new SearchAssetDto()
      this.token=localStorage.getItem("token")
      this._userService.getAssetCategory(this.token).subscribe(x=>{
        this.categoryOptions=x      
        this.categoryOptions.unshift("------")
        this.selectedCategory="------"

      })
        this._userService.showAvailableAsset(this.token).subscribe(x=>{
          this.assets=x
          this.dataSource = new MatTableDataSource(this.assets);
          this.dataSource.sort = this.sort
          this.dataSource.paginator = this.paginator;
        })
      
      
  }

handleChange(){
  this.searchAssetDto.assetName=this.assetSearch
  this.searchAssetDto.category=this.selectedCategory

  if((this.selectedCategory==null && this.assetSearch=="") || (this.selectedCategory=="------" && this.assetSearch=="") ){
    this._userService.showAvailableAsset(this.token).subscribe(x=>{
      this.assets=x
      this.dataSource = new MatTableDataSource(this.assets);
      this.dataSource.sort = this.sort
      this.dataSource.paginator = this.paginator;
    })
  }
  else if((this.selectedCategory!="------" && this.assetSearch!=null)){
    this._userService.searchAssetByNameAndCategory(this.searchAssetDto,this.token).subscribe(x=>{
      this.assets=x
      this.dataSource = new MatTableDataSource(this.assets);
      this.dataSource.sort = this.sort
      this.dataSource.paginator = this.paginator;
    })
  }
  else{
    this._userService.searchAssetByNameOrCategory(this.searchAssetDto,this.token).subscribe(x=>{
      this.assets=x
      this.dataSource = new MatTableDataSource(this.assets);
      this.dataSource.sort = this.sort
      this.dataSource.paginator = this.paginator;
  })
  }
}




  handleRequest(assetId:number){
    this.userId=parseInt(localStorage.getItem("id"))
    this._userService.requestAsset(this.userId,assetId,this.token).subscribe(x=>{
      this._toastr.success(x,'Success')
    })
  }

}
