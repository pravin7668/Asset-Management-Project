import { Component } from '@angular/core';
import { User } from '../../class/user';
import { UserService } from '../../service/user.service';
import { MatDialog } from '@angular/material/dialog';
import { UserUpdateComponent } from '../user-update/user-update.component';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})
export class UserComponent {
  u:User
  id:number
  token:string
  constructor(private _userService:UserService,private _dialog:MatDialog){
    this.id=parseInt(localStorage.getItem("id"))
    this.token=localStorage.getItem("token")
    _userService.findUserById(this.id,this.token).subscribe(x=>{
      this.u=x
    })
  }

  handleClick(user:User){
    const dialogRef = this._dialog.open(UserUpdateComponent,{
      height:'500px',
      width:'600px',
      data:user
    })

    dialogRef.afterClosed().subscribe(x=>{
      this._userService.findUserById(this.id,this.token).subscribe(x=>{
        this.u=x
      })
    })

}



}
