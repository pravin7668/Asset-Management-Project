import { Component, Input } from '@angular/core';
import { AssetServiceRequestDto } from '../../class/asset-service-request-dto';

@Component({
  selector: 'app-service-request-status-card',
  templateUrl: './service-request-status-card.component.html',
  styleUrl: './service-request-status-card.component.css'
})
export class ServiceRequestStatusCardComponent {
      @Input() asset!:AssetServiceRequestDto
}
