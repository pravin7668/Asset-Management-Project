import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceRequestStatusCardComponent } from './service-request-status-card.component';

describe('ServiceRequestStatusCardComponent', () => {
  let component: ServiceRequestStatusCardComponent;
  let fixture: ComponentFixture<ServiceRequestStatusCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ServiceRequestStatusCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ServiceRequestStatusCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
