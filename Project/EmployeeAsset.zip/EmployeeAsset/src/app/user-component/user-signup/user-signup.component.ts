import { Component } from '@angular/core';
import { User } from '../../class/user';
import { UserService } from '../../service/user.service';
import { Router } from '@angular/router';
import { AbstractControl, FormBuilder, FormGroup, NgForm, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { AuthService } from '../../service/auth.service';
import { MailHeaders } from '../../class/mail-headers';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-user-signup',
  templateUrl: './user-signup.component.html',
  styleUrl: './user-signup.component.css'
})
export class UserSignupComponent {

  user:User
  passwordStrength:number=0
  otp:string
  userEnteredOtp:string
  otpInput:boolean
  otpButton:boolean
  isOtpValid:boolean
  isEmailVerified:boolean
  mailHeaders:MailHeaders
  signUpForm:FormGroup

  constructor(private _userService:UserService,private _authService:AuthService,private _formBuilder:FormBuilder,private _router:Router,private _toastr:ToastrService,
    private _dialogRef:MatDialogRef<UserSignupComponent>
  ){
    this.otpInput=false
    this.mailHeaders=new MailHeaders()
    this.user=new User()
  }
  ngOnInit():void{
    this.signUpForm=this._formBuilder.group({
      'firstName':['',Validators.required],
      'lastName':['',Validators.required],
      'address':['',Validators.required],
      'phoneno':['',[Validators.required,this.phonenoValidator()]],
      'email':['',[Validators.required,Validators.email]],
      'otp':['',Validators.required],
      'password':['',[Validators.required,this.passwordValidator()]],
      'confirmPassword':['',Validators.required]
    
    },{validators :this.passwordCheck})

    this.signUpForm.get('email')?.statusChanges.subscribe(status=>{
      if(this.signUpForm.get('email').dirty){
        this.isEmailVerified=false
        this.otpButton=true
      }
    })

    this.signUpForm.get('otp').valueChanges.subscribe(val=>{
      if(this.signUpForm.get('otp').dirty){
        this.isOtpValid=false
      }
    })

    this.signUpForm.get('password')?.valueChanges.subscribe(value=>{
      this.passwordStrength=this.calculatePasswordStrength(value)
    })
  }

    calculatePasswordStrength(password: string): number {
    let strength = 0;
    if (password.length >= 8) {
      strength += 1;
    }
    if (/[A-Z]/.test(password)) {
      strength += 1;
    }
    if (/[a-z]/.test(password)) {
      strength += 1;
    }
    if (/[0-9]/.test(password)) {
      strength += 1;
    }
    if (/[!@#$%^&*(),.?":{}|<>]+/.test(password)) {
      strength += 1;
    }
    console.log(strength)
    return strength;
  }



  phonenoValidator():ValidatorFn {
    return (control:AbstractControl):ValidationErrors | null =>{
    const phoneno=control.value
    const err:ValidationErrors={}
    if(/[a-z]+/.test(phoneno) || /[A-Z]+/.test(phoneno)){
      err['hasCharacters']=true
    }
    if(phoneno.length>10){
      err['hasMoreNumber']=true
    }
    if(phoneno.length<10){
      err['hasLessNumber']=true
    }
    return Object.keys(err).length>0?err:null
  }
}

  passwordCheck: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
    const password = control.get('password').value;
    const confirmPassword = control.get('confirmPassword').value;
    const err:ValidationErrors={}
    if (password !== confirmPassword) {
      err['passwordMismatch']=true 
    }
    return Object.keys(err).length>0?err:null
  };
  
  

  passwordValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value=control.value
      const err:ValidationErrors={}
      if(!/[A-Z]+/.test(value)){
        err['hasMissing']=true
      }
      if(!/[a-z]+/.test(value)){
        err['hasMissing']=true
      }
      if(!/[0-9]+/.test(value)){
        err['hasMissing']=true
      }

      if(!/[!@#$%^&*(),.?":{}|<>]+/.test(value)){
        err['hasMissing']=true
      }
      if(value.length<8){
        err['hasMissing']=true
      }

      return Object.keys(err).length>0?err:null
}
}
  checkSignup():void{
    if(this.signUpForm.valid){
        console.log("Form Submitted",this.signUpForm.value)
        this.user=this.signUpForm.value
        this.user.status="Active"
        this._userService.addUser(this.user).subscribe(x=>{

          // this._router.navigate(['user-login'])
        })
        this._toastr.success("User Added Successfully","Success")
        this._dialogRef.close()

      }
    else{
      this._toastr.error("Please Fill the Required Field","Error")
        this.signUpForm.markAllAsTouched()
    }
          //   this._toastr.success("User Added Successfully","Success")
          // this._dialogRef.close()
  }

  handleOtp():void{
    this.otpInput=true
    this.otp = generateNumericOTP(6);
    console.log(this.signUpForm.get('email').value)
    this.mailHeaders.toEmail=this.signUpForm.get('email').value
    this.mailHeaders.subject="OTP for Mail Verification"
    this.mailHeaders.body="Your OTP "+this.otp
    console.log(this.mailHeaders)
    this._authService.sendMail(this.mailHeaders).subscribe(x=>{
      this._toastr.success("OTP has been Sent to the Successfully","Success")
    })
    console.log('Generated OTP:', this.otp);

  }
  validateOtp():void{
    this.userEnteredOtp=this.signUpForm.get('otp').value
    console.log(this.userEnteredOtp)
    if(this.otp===this.userEnteredOtp){
      this.otpInput=false
      this.otpButton=false
      this.isEmailVerified=true
    }
    else{
      this.isOtpValid=true
    }

  }







  // user:User
  // isValid:boolean
  // constructor(private _userService:UserService,private _router:Router){
  //   this.user=new User()
  //   this.isValid=false
  // }
  // checkSignup(signupForm:NgForm){
  //     if(signupForm.invalid){
  //       return
  //     }
  //     this.isValid=true
  //     this.user.status="Active"
  //     alert(this.user.firstName)
  //     this._userService.addUser(this.user).subscribe(x=>{
  //         console.log(x)
  //     })
  //     alert("User Added Successfully")
  //     this._router.navigate(['user-login'])
  // }
}

function generateNumericOTP(length: number): string {
  const digits = '0123456789';
  let otp = '';

  for (let i = 0; i < length; i++) {
    otp += digits[Math.floor(Math.random() * digits.length)];
  }

  return otp;
}