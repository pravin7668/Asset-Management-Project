import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetRequestStatusComponent } from './asset-request-status.component';

describe('AssetRequestStatusComponent', () => {
  let component: AssetRequestStatusComponent;
  let fixture: ComponentFixture<AssetRequestStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AssetRequestStatusComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetRequestStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
