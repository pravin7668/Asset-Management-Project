import { Component, ViewChild } from '@angular/core';
import { AssetRequestDto } from '../../class/asset-request-dto';
import { UserService } from '../../service/user.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { AllocatedAssetDto } from '../../class/allocated-asset-dto';

@Component({
  selector: 'app-asset-request-status',
  templateUrl: './asset-request-status.component.html',
  styleUrl: './asset-request-status.component.css'
})
export class AssetRequestStatusComponent {
  displayedColumns:string[]=[
    'assetId',
    'assetName',
    'userId',
    'firstName',
    'requestType',
    'status'
  ]
  allocatedAssetDto:AllocatedAssetDto[]
  id:number
  noData:boolean
  dataSource=new MatTableDataSource<AllocatedAssetDto>
  token:string
  @ViewChild(MatSort) sort={} as MatSort
  @ViewChild(MatPaginator) paginator={} as MatPaginator
  constructor(private _userService:UserService){
    this.noData=false
    this.id=parseInt(localStorage.getItem("id"))
    this.token=localStorage.getItem("token")
    this._userService.assetRequestStatus(this.id,this.token).subscribe(x=>{
      this.allocatedAssetDto=x
      if(this.allocatedAssetDto.length==0){
        this.noData=true
      }
      this.dataSource=new MatTableDataSource(this.allocatedAssetDto)
        this.dataSource.paginator=this.paginator
        this.dataSource.sort=this.sort
    })
  }
}
