import { Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { UserService } from '../service/user.service';
import { Router } from '@angular/router';
import { AllocatedAssetDto } from '../class/allocated-asset-dto';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrl: './test.component.css'
})
export class TestComponent {
  myAssets:AllocatedAssetDto[]
  displayedColumns:string[]=[
    'assetId',
    'assetName',
    'userId',
    'firstName',
    'issuedDate',
    'serviceButton',
    'returnButton'
  ]
  id:number
  token:string
  dataSource=new MatTableDataSource<AllocatedAssetDto>
  @ViewChild(MatSort) sort={} as MatSort
  @ViewChild(MatPaginator) paginator={} as MatPaginator
  constructor(private _userService:UserService,private _router:Router){



    this.id=parseInt(localStorage.getItem("id"))
    this.token=localStorage.getItem("token")
    this._userService.myAssets(this.id,this.token).subscribe(x=>{
      this.myAssets=x
      this.dataSource=new MatTableDataSource(this.myAssets)
      this.dataSource.paginator=this.paginator
      this.dataSource.sort=this.sort
    })
  }
  handleService(requestId:number){
      this._router.navigate(['/user-menu',{outlets:{'hexa':['service-request']}}],{queryParams:{
        requestId:requestId
      }})
  }
  
  res:string
  handleReturn(requestId:number){
      this._userService.assetReturnRequest(requestId,this.token).subscribe(x=>{
          this.res=x.res
          alert(this.res)
          
      })
  }
}
