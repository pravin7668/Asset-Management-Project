import { Component, ViewChild } from '@angular/core';
import { Asset } from '../../class/asset';
import { AdminService } from '../../service/admin.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { SearchAssetDto } from '../../class/search-asset-dto';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-show-available-asset',
  templateUrl: './show-available-asset.component.html',
  styleUrl: './show-available-asset.component.css'
})
export class ShowAvailableAssetComponent {
  displayedColumns: string[] = [
    'assetId',
    'assetName',
    'assetCategory',
    'assetDescription',
    'manufacturingDate',
    'expiryDate',
    'deleteAssetButton'
  ];
  token:string
  assets:Asset[]
  searchAssetDto:SearchAssetDto
  assetSearch:string
  selectedCategory:string
  categoryOptions:string[]
    dataSource=new MatTableDataSource<Asset>
    @ViewChild(MatSort) sort = {} as MatSort;
    @ViewChild(MatPaginator) paginator = {} as MatPaginator;
  constructor(private _adminService:AdminService,private _toastr:ToastrService){
    this.searchAssetDto=new SearchAssetDto()
      this.token=localStorage.getItem("token")

      this._adminService.getAssetCategory(this.token).subscribe(x=>{
        this.categoryOptions=x      
        this.categoryOptions.unshift("------")
        this.selectedCategory="------"

      })

      this._adminService.showAvailableAsset(this.token).subscribe(x=>{
        this.assets=x
        this.dataSource = new MatTableDataSource(this.assets);
        this.dataSource.sort = this.sort
        this.dataSource.paginator = this.paginator;
      })
  }
  res:string
  handleDeleteAsset(assetId:number){
    this._adminService.deleteAsset(assetId,this.token).subscribe(x=>{
      this.res=x
      this._toastr.success(this.res,'Success')
      this._adminService.showAvailableAsset(this.token).subscribe(x=>{
        this.assets=x
        this.dataSource = new MatTableDataSource(this.assets);
        this.dataSource.sort = this.sort
        this.dataSource.paginator = this.paginator;
      })
    })
  }

  handleChange(){
    this.searchAssetDto.assetName=this.assetSearch
    this.searchAssetDto.category=this.selectedCategory
  
    if((this.selectedCategory==null && this.assetSearch=="") || (this.selectedCategory=="------" && this.assetSearch=="") ){
      this._adminService.showAvailableAsset(this.token).subscribe(x=>{
        this.assets=x
        this.dataSource = new MatTableDataSource(this.assets);
        this.dataSource.sort = this.sort
        this.dataSource.paginator = this.paginator;
      })
    }
    else if((this.selectedCategory!="------" && this.assetSearch!=null)){
      this._adminService.searchAssetByNameAndCategory(this.searchAssetDto,this.token).subscribe(x=>{
        this.assets=x
        this.dataSource = new MatTableDataSource(this.assets);
        this.dataSource.sort = this.sort
        this.dataSource.paginator = this.paginator;
      })
    }
    else{
      this._adminService.searchAssetByNameOrCategory(this.searchAssetDto,this.token).subscribe(x=>{
        this.assets=x
        this.dataSource = new MatTableDataSource(this.assets);
        this.dataSource.sort = this.sort
        this.dataSource.paginator = this.paginator;
    })
    }
  }
}
