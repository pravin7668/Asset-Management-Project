import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAvailableAssetComponent } from './show-available-asset.component';

describe('ShowAvailableAssetComponent', () => {
  let component: ShowAvailableAssetComponent;
  let fixture: ComponentFixture<ShowAvailableAssetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ShowAvailableAssetComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowAvailableAssetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
