import { Component, ViewChild } from '@angular/core';
import { AllocatedAssetDto } from '../../class/allocated-asset-dto';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { AdminService } from '../../service/admin.service';
import { SearchAssetAllocatedToUser } from '../../class/search-asset-allocated-to-user';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-pending-asset-audit',
  templateUrl: './pending-asset-audit.component.html',
  styleUrl: './pending-asset-audit.component.css'
})
export class PendingAssetAuditComponent {
  displayedColumns:string[]=[
    'assetId',
    'assetName',
    'userId',
    'firstName',
    'issuedDate',
    'auditStatus',
    'verifyAuditButton'
  ]
  userAssets:AllocatedAssetDto[]
  userSearch :SearchAssetAllocatedToUser
  userId:number
  inputType:string
  token:string
  noData:boolean
  id:number
  dataSource=new MatTableDataSource<AllocatedAssetDto>
  @ViewChild(MatSort) sort={} as MatSort
  @ViewChild(MatPaginator) paginator={} as MatPaginator
  constructor(private _adminService:AdminService,private _toastr:ToastrService){
    this.userSearch=new SearchAssetAllocatedToUser()
    this.noData=false
    this.token=localStorage.getItem("token")
    this._adminService.showPendingAuditRequest(this.token).subscribe(x=>{
      this.userAssets=x
      if(this.userAssets.length==0){
        this.noData=true
      }
      this.dataSource=new MatTableDataSource(this.userAssets)
      this.dataSource.paginator=this.paginator
      this.dataSource.sort=this.sort
    })
  }
  res:string
  handleVerifyAudit(requestId:number){
    this._adminService.verifyAuditRequest(requestId,this.token).subscribe(x=>{
      this.res=x
      this._toastr.success(this.res,'Success')
      this._adminService.showPendingAuditRequest(this.token).subscribe(x=>{
        this.userAssets=x
        if(this.userAssets.length==0){
          this.noData=true
        }
        this.dataSource=new MatTableDataSource(this.userAssets)
        this.dataSource.paginator=this.paginator
        this.dataSource.sort=this.sort
      })
    })
  }

  handleChange(){
    this.checkInputType(this.userSearch.inputFromAngular)
    if(this.userSearch.inputFromAngular==""){
      this._adminService.showPendingAuditRequest(this.token).subscribe(x=>{
        this.userAssets=x
        this.dataSource=new MatTableDataSource(this.userAssets)
        this.dataSource.paginator=this.paginator
        this.dataSource.sort=this.sort
      })
    }
    else if(this.inputType=="Integer"){
          this.userId=parseInt(this.userSearch.inputFromAngular)
          this._adminService.searchAuditRequestByUserId(this.userSearch,this.token).subscribe(x=>{
            this.userAssets=x
            this.dataSource=new MatTableDataSource(this.userAssets)
            this.dataSource.paginator=this.paginator
            this.dataSource.sort=this.sort
          })

        }else{
          this._adminService.searchAuditRequestByNameAndEmail(this.userSearch,this.token).subscribe(x=>{
            this.userAssets=x
            this.dataSource=new MatTableDataSource(this.userAssets)
            this.dataSource.paginator=this.paginator
            this.dataSource.sort=this.sort
          })
        }
  }

  checkInputType(value: string): void {
    const parsedValue = parseInt(value);

    if (Number.isInteger(parsedValue)) {
      this.inputType = 'Integer';
    } else {
      this.inputType = 'String';
    }
  }
}
