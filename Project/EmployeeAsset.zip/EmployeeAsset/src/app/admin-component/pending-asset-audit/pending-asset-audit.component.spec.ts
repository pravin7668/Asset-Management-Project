import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingAssetAuditComponent } from './pending-asset-audit.component';

describe('PendingAssetAuditComponent', () => {
  let component: PendingAssetAuditComponent;
  let fixture: ComponentFixture<PendingAssetAuditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PendingAssetAuditComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PendingAssetAuditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
