import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Asset } from '../../class/asset';

@Component({
  selector: 'app-show-asset-card',
  templateUrl: './show-asset-card.component.html',
  styleUrl: './show-asset-card.component.css'
})
export class ShowAssetCardComponent {
  @Input() asset:Asset
  @Output() approveClicked=new EventEmitter<Asset>

  onApproveClick(){
    this.approveClicked.emit(this.asset)
  }
}
