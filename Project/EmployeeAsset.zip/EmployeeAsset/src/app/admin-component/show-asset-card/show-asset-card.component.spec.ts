import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAssetCardComponent } from './show-asset-card.component';

describe('ShowAssetCardComponent', () => {
  let component: ShowAssetCardComponent;
  let fixture: ComponentFixture<ShowAssetCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ShowAssetCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowAssetCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
