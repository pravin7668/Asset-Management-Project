import { Component, EventEmitter, Input, Output } from '@angular/core';
import { PendingAssetRequest } from '../pending-asset-request/pending-asset-request.component';

@Component({
  selector: 'app-pending-asset-request-card',
  templateUrl: './pending-asset-request-card.component.html',
  styleUrl: './pending-asset-request-card.component.css'
})
export class PendingAssetRequestCardComponent {
  @Input() asset:PendingAssetRequest
  @Output() approveClicked=new EventEmitter<PendingAssetRequest>

  onApproveClick(){
    this.approveClicked.emit(this.asset)
  }
}
