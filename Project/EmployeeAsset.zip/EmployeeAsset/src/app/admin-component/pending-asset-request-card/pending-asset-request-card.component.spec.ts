import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingAssetRequestCardComponent } from './pending-asset-request-card.component';

describe('PendingAssetRequestCardComponent', () => {
  let component: PendingAssetRequestCardComponent;
  let fixture: ComponentFixture<PendingAssetRequestCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PendingAssetRequestCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PendingAssetRequestCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
