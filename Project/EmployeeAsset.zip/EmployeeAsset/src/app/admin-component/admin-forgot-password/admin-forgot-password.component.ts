import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { AdminService } from '../../service/admin.service';
import { AuthService } from '../../service/auth.service';
import { Router } from '@angular/router';
import { MailHeaders } from '../../class/mail-headers';
import { User } from '../../class/user';
import { ForgotPasswordDto } from '../../class/forgot-password-dto';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-admin-forgot-password',
  templateUrl: './admin-forgot-password.component.html',
  styleUrl: './admin-forgot-password.component.css'
})
export class AdminForgotPasswordComponent {
  
  forgotPasswordDto:ForgotPasswordDto
  passwordStrength:number=0
  otp:string
  userEnteredOtp:string
  otpInput:boolean
  otpButton:boolean
  isOtpValid:boolean
  isEmailVerified:boolean
  mailHeaders:MailHeaders
  signUpForm:FormGroup

  constructor(private _adminService:AdminService,private _authService:AuthService,private _formBuilder:FormBuilder,private _router:Router,private _toastr:ToastrService,
    private _dialogRef:MatDialogRef<AdminForgotPasswordComponent>
  ){
    this.otpInput=false
    this.mailHeaders=new MailHeaders()
    this.forgotPasswordDto=new ForgotPasswordDto()
  }
  ngOnInit():void{
    this.signUpForm=this._formBuilder.group({
      'email':['',[Validators.required,Validators.email]],
      'otp':['',Validators.required],
      'password':['',[Validators.required,this.passwordValidator()]],
      'confirmPassword':['',Validators.required]
    
    },{validators :this.passwordCheck})

    this.signUpForm.get('email')?.statusChanges.subscribe(status=>{
      if(this.signUpForm.get('email').dirty){
        this.isEmailVerified=false
        this.otpButton=true
      }
    })

    this.signUpForm.get('otp').valueChanges.subscribe(val=>{
      if(this.signUpForm.get('otp').dirty){
        this.isOtpValid=false
      }
    })

    this.signUpForm.get('password').valueChanges.subscribe(value=>{
      this.passwordStrength=this.calculatePasswordStrength(value)
    })
  }

    calculatePasswordStrength(password: string): number {
    let strength = 0;
    if (password.length >= 8) {
      strength += 1;
    }
    if (/[A-Z]/.test(password)) {
      strength += 1;
    }
    if (/[a-z]/.test(password)) {
      strength += 1;
    }
    if (/[0-9]/.test(password)) {
      strength += 1;
    }
    if (/[!@#$%^&*(),.?":{}|<>]+/.test(password)) {
      strength += 1;
    }
    console.log(strength)
    return strength;
  }


  passwordCheck: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
    const password = control.get('password').value;
    const confirmPassword = control.get('confirmPassword').value;
    const err:ValidationErrors={}
    if (password !== confirmPassword) {
      err['passwordMismatch']=true 
    }
    return Object.keys(err).length>0?err:null
  };
  
  passwordValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value=control.value
      const err:ValidationErrors={}
      if(!/[A-Z]+/.test(value)){
        err['hasMissing']=true
      }
      if(!/[a-z]+/.test(value)){
        err['hasMissing']=true
      }
      if(!/[0-9]+/.test(value)){
        err['hasMissing']=true
      }

      if(!/[!@#$%^&*(),.?":{}|<>]+/.test(value)){
        err['hasMissing']=true
      }
      if(value.length<8){
        err['hasMissing']=true
      }

      return Object.keys(err).length>0?err:null
}
}
  handleForgotPassword():void{
    if(this.signUpForm.valid){
        console.log("Form Submitted",this.signUpForm.value)
        this.forgotPasswordDto.email=this.signUpForm.get('email').value
        this.forgotPasswordDto.newPassword=this.signUpForm.get('password').value
        console.log(this.forgotPasswordDto)
        this._authService.forgotPasswordAdmin(this.forgotPasswordDto).subscribe(x=>{
            
        })
        this._dialogRef.close()
        this._toastr.success("Password has been changed successfully","Success")
        
        // this._router.navigate(['admin-login'])
    }
    else{
      this._toastr.error("Please Fill the Required Field","Error")
        this.signUpForm.markAllAsTouched()
    }
  }

  handleOtp():void{
    this.otpInput=true
    this.otp = generateNumericOTP(6);
    console.log(this.signUpForm.get('email').value)
    this.mailHeaders.toEmail=this.signUpForm.get('email').value
    this.mailHeaders.subject="OTP for Mail Verification"
    this.mailHeaders.body="Your OTP "+this.otp
    console.log(this.mailHeaders)
    this._authService.sendMail(this.mailHeaders).subscribe(x=>{
      this._toastr.success("OTP Sent to the Mail","Success")

    })
    console.log('Generated OTP:', this.otp);

  }
  validateOtp():void{
    this.userEnteredOtp=this.signUpForm.get('otp').value
    console.log(this.userEnteredOtp)
    if(this.otp===this.userEnteredOtp){
      this.otpInput=false
      this.otpButton=false
      this.isEmailVerified=true
    }
    else{
      this.isOtpValid=true
    }

  }
}

function generateNumericOTP(length: number): string {
  const digits = '0123456789';
  let otp = '';

  for (let i = 0; i < length; i++) {
    otp += digits[Math.floor(Math.random() * digits.length)];
  }

  return otp;
}