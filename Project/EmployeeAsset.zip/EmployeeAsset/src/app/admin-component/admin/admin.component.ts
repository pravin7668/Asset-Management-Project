import { Component } from '@angular/core';
import { AdminService } from '../../service/admin.service';
import { User } from '../../class/user';
import { Admin } from '../../class/admin';
import { MatDialog } from '@angular/material/dialog';
import { UserUpdateComponent } from '../../user-component/user-update/user-update.component';
import { AdminUpdateComponent } from '../admin-update/admin-update.component';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css'
})
export class AdminComponent {
  u:Admin
  id:number
  token:string
  constructor(private _adminService:AdminService,private _dialog:MatDialog){
    this.id=parseInt(localStorage.getItem("id"))
    this.token=localStorage.getItem("token")
    _adminService.findAdminById1(this.id).subscribe(x=>{
      this.u=x
    })
  }

  handleClick(user:Admin){
    const dialogRef = this._dialog.open(AdminUpdateComponent,{
      height:'500px',
      width:'600px',
      data:user
    })

    dialogRef.afterClosed().subscribe(x=>{
      this._adminService.findAdminById1(this.id).subscribe(x=>{
        this.u=x
      })
    })

}

}
