import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingAssetRequestComponent } from './pending-asset-request.component';

describe('PendingAssetRequestComponent', () => {
  let component: PendingAssetRequestComponent;
  let fixture: ComponentFixture<PendingAssetRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PendingAssetRequestComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PendingAssetRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
