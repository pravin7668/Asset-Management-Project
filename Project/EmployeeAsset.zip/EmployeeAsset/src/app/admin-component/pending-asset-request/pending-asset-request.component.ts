import { Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { AdminService } from '../../service/admin.service';
import { SearchAssetAllocatedToUser } from '../../class/search-asset-allocated-to-user';
import { ToastrService } from 'ngx-toastr';

export type PendingAssetRequest={
  requestId:number
  userId:number
  firstName:string
  assetId:number
  assetName:string
  imageUrl:string
  assetDescription:string
}


@Component({
  selector: 'app-pending-asset-request',
  templateUrl: './pending-asset-request.component.html',
  styleUrl: './pending-asset-request.component.css'
})
export class PendingAssetRequestComponent {
  userAssets:PendingAssetRequest[]
  token:string
  userSearch :SearchAssetAllocatedToUser
  userIdSearch:number
  inputType:string
  noData:boolean
  adminId:number
  displayedColumns: string[] = [
    'requestId',
    'userId',
    'firstName',
    'assetId',
    'assetName',
    'approveButton'
  
  ];
  dataSource=new MatTableDataSource<PendingAssetRequest>
  @ViewChild(MatSort) sort = {} as MatSort;
  @ViewChild(MatPaginator) paginator = {} as MatPaginator;
  constructor(private _adminService:AdminService,private _toastr:ToastrService){
    this.noData=false
    this.userSearch=new SearchAssetAllocatedToUser()
      this.token=localStorage.getItem("token")
      this._adminService.showPendingAssetRequest(this.token).subscribe(x=>{
        this.userAssets=x
        if(this.userAssets.length==0){
          this.noData=true
        }
        this.dataSource = new MatTableDataSource(this.userAssets);
      this.dataSource.sort = this.sort
      this.dataSource.paginator = this.paginator;
      })
  }
  res:string
  handleApprove(requestId:number){
    this.adminId=parseInt(localStorage.getItem("id"))
    this._adminService.approvePendingAssetRequest(this.adminId,requestId,this.token).subscribe(x=>{
        this.res=x
        this._toastr.success(this.res,'Success')
        this._adminService.showPendingAssetRequest(this.token).subscribe(x=>{
          this.userAssets=x
          if(this.userAssets.length==0){
            this.noData=true
          }
          this.dataSource = new MatTableDataSource(this.userAssets);
        this.dataSource.sort = this.sort
        this.dataSource.paginator = this.paginator;
        })

    })
  }

  handleChange(){
    this.checkInputType(this.userSearch.inputFromAngular)
    if(this.userSearch.inputFromAngular==""){
      this._adminService.showPendingAssetRequest(this.token).subscribe(x=>{
        this.userAssets=x
        this.dataSource=new MatTableDataSource(this.userAssets)
        this.dataSource.paginator=this.paginator
        this.dataSource.sort=this.sort
      })
    }
    else if(this.inputType=="Integer"){
          this.userIdSearch=parseInt(this.userSearch.inputFromAngular)
          this._adminService.searchAssetAllocationRequestByUserId(this.userSearch,this.token).subscribe(x=>{
            this.userAssets=x
            this.dataSource=new MatTableDataSource(this.userAssets)
            this.dataSource.paginator=this.paginator
            this.dataSource.sort=this.sort
          })

        }else{
          this._adminService.searchAssetAllocationRequestByNameAndEmail(this.userSearch,this.token).subscribe(x=>{
            this.userAssets=x
            this.dataSource=new MatTableDataSource(this.userAssets)
            this.dataSource.paginator=this.paginator
            this.dataSource.sort=this.sort
          })
        }
  }

  checkInputType(value: string): void {
    const parsedValue = parseInt(value);

    if (Number.isInteger(parsedValue)) {
      this.inputType = 'Integer';
    } else {
      this.inputType = 'String';
    }
  }
}
