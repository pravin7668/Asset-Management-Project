import { Component, EventEmitter, Input, Output } from '@angular/core';
import { PendingReturnRequest } from '../show-return-asset-request/show-return-asset-request.component';

@Component({
  selector: 'app-show-return-request-card',
  templateUrl: './show-return-request-card.component.html',
  styleUrl: './show-return-request-card.component.css'
})
export class ShowReturnRequestCardComponent {
  @Input() asset:PendingReturnRequest
  @Output() approveClicked=new EventEmitter<PendingReturnRequest>
  
  onApproveClick(){
    this.approveClicked.emit(this.asset)
  }
}
