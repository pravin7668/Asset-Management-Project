import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowReturnRequestCardComponent } from './show-return-request-card.component';

describe('ShowReturnRequestCardComponent', () => {
  let component: ShowReturnRequestCardComponent;
  let fixture: ComponentFixture<ShowReturnRequestCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ShowReturnRequestCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowReturnRequestCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
