import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowReturnAssetRequestComponent } from './show-return-asset-request.component';

describe('ShowReturnAssetRequestComponent', () => {
  let component: ShowReturnAssetRequestComponent;
  let fixture: ComponentFixture<ShowReturnAssetRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ShowReturnAssetRequestComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowReturnAssetRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
