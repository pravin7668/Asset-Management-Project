import { Component, ViewChild, ViewEncapsulation } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { AdminService } from '../../service/admin.service';
import { MatPaginator } from '@angular/material/paginator';
import { SearchAssetAllocatedToUser } from '../../class/search-asset-allocated-to-user';
import { ToastrService } from 'ngx-toastr';

export type PendingReturnRequest={
  requestId:number
  userId:number
  firstName:string
  assetId:number
  assetName:string
  issuedDate:string
  assetDescription:string
  imageUrl:string
}

@Component({
  selector: 'app-show-return-asset-request',
  templateUrl: './show-return-asset-request.component.html',
  styleUrl: './show-return-asset-request.component.css',
  encapsulation:ViewEncapsulation.None
})
export class ShowReturnAssetRequestComponent {
  userAssets:PendingReturnRequest[]
  userSearch :SearchAssetAllocatedToUser
  userIdSearch:number
  inputType:string
  token:string
  adminId:number
  displayedColumns: string[] = [
    'userId',
    'firstName',
    'assetId',
    'assetName',
    'issuedDate',
    'approveButton'
  
  ];
  noData:boolean
  dataSource=new MatTableDataSource<PendingReturnRequest>
  @ViewChild(MatSort) sort = {} as MatSort;
  @ViewChild(MatPaginator) paginator = {} as MatPaginator;

  constructor(private _adminService:AdminService,private _toastr:ToastrService){
    this.userSearch=new SearchAssetAllocatedToUser()
      this.noData=false
      this.token=localStorage.getItem("token")
      this._adminService.showPendingReturnRequest(this.token).subscribe(x=>{
        this.userAssets=x
        if(this.userAssets.length==0){
          this.noData=true
        }
        this.dataSource = new MatTableDataSource(this.userAssets);
      this.dataSource.sort = this.sort
      this.dataSource.paginator = this.paginator;
      })
  }
  res:string
  handleApprove(requestId:number){
    this.adminId=parseInt(localStorage.getItem("id"))
    this._adminService.approvePendingReturnRequest(requestId,this.token).subscribe(x=>{
        this.res=x
        this._toastr.success("Asset Return Request Approved",'Success')
        this._adminService.showPendingReturnRequest(this.token).subscribe(x=>{
          this.userAssets=x
          if(this.userAssets.length==0){
            this.noData=true
          }
          this.dataSource = new MatTableDataSource(this.userAssets);
        this.dataSource.sort = this.sort
        this.dataSource.paginator = this.paginator;
        })

    })
  }

  handleChange(){
    this.checkInputType(this.userSearch.inputFromAngular)
    if(this.userSearch.inputFromAngular==""){
      this._adminService.showPendingReturnRequest(this.token).subscribe(x=>{
        this.userAssets=x
        this.dataSource=new MatTableDataSource(this.userAssets)
        this.dataSource.paginator=this.paginator
        this.dataSource.sort=this.sort
      })
    }
    else if(this.inputType=="Integer"){
          this.userIdSearch=parseInt(this.userSearch.inputFromAngular)
          this._adminService.searchReturnRequestByUserId(this.userSearch,this.token).subscribe(x=>{
            this.userAssets=x
            this.dataSource=new MatTableDataSource(this.userAssets)
            this.dataSource.paginator=this.paginator
            this.dataSource.sort=this.sort
          })

        }else{
          this._adminService.searchReturnRequestByNameAndEmail(this.userSearch,this.token).subscribe(x=>{
            this.userAssets=x
            this.dataSource=new MatTableDataSource(this.userAssets)
            this.dataSource.paginator=this.paginator
            this.dataSource.sort=this.sort
          })
        }
  }

  checkInputType(value: string): void {
    const parsedValue = parseInt(value);

    if (Number.isInteger(parsedValue)) {
      this.inputType = 'Integer';
    } else {
      this.inputType = 'String';
    }
  }
}
