import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAssetWithSearchComponent } from './show-asset-with-search.component';

describe('ShowAssetWithSearchComponent', () => {
  let component: ShowAssetWithSearchComponent;
  let fixture: ComponentFixture<ShowAssetWithSearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ShowAssetWithSearchComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowAssetWithSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
