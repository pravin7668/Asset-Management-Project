import { Component, ViewChild } from '@angular/core';
import { Asset } from '../../class/asset';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { AdminService } from '../../service/admin.service';
import { Router } from '@angular/router';
import { SearchAssetDto } from '../../class/search-asset-dto';

@Component({
  selector: 'app-show-asset-with-search',
  templateUrl: './show-asset-with-search.component.html',
  styleUrl: './show-asset-with-search.component.css'
})
export class ShowAssetWithSearchComponent {
  assets:Asset[]
  searchAssetDto:SearchAssetDto
  assetSearch:string
  selectedCategory:string
  categoryOptions:string[]
  token:string
  displayedColumns: string[] = [
    'assetId',
    'assetName',
    'assetCategory',
    'assetDescription',
    'manufacturingDate',
    'expiryDate',
    'updateAssetButton'
  ];
  dataSource=new MatTableDataSource<Asset>
  @ViewChild(MatSort) sort = {} as MatSort;
  @ViewChild(MatPaginator) paginator = {} as MatPaginator;
  constructor(private _adminService:AdminService,private _router:Router){
      this.searchAssetDto=new SearchAssetDto()
      this.token=localStorage.getItem("token")
      this._adminService.getAssetCategory(this.token).subscribe(x=>{
        this.categoryOptions=x      
        this.categoryOptions.unshift("------")
        this.selectedCategory="------"

      })
      this._adminService.showAsset(this.token).subscribe(x=>{
        this.assets=x
        this.dataSource = new MatTableDataSource(this.assets);
      this.dataSource.sort = this.sort
      this.dataSource.paginator = this.paginator;
      })
  }

  handleAddAsset(){
      this._router.navigate(['/admin-menu',{outlets:{'admin':['add-asset']}}])
  }

  handleUpdateAsset(asset:Asset){
    this._router.navigate(['/admin-menu',{outlets:{'admin':['update-asset']}}],{queryParams:{
      assetId:asset.assetId,
      assetName:asset.assetName,
      assetCategory:asset.assetCategory,
      assetModel:asset.assetModel,
      assetDescription:asset.assetDescription,
      assetValue:asset.assetValue,
      manufacturingDate:asset.manufacturingDate,
      expiryDate:asset.expiryDate,
      status:asset.status,
      imageUrl:asset.imageUrl
    }})
  }

  handleChange(){
    this.searchAssetDto.assetName=this.assetSearch
    this.searchAssetDto.category=this.selectedCategory
  
    if((this.selectedCategory==null && this.assetSearch=="") || (this.selectedCategory=="------" && this.assetSearch=="") ){
      this._adminService.showAsset(this.token).subscribe(x=>{
        this.assets=x
        this.dataSource = new MatTableDataSource(this.assets);
        this.dataSource.sort = this.sort
        this.dataSource.paginator = this.paginator;
      })
    }
    else if((this.selectedCategory!="------" && this.assetSearch!=null)){
      this._adminService.searchAllAssetByNameAndCategory(this.searchAssetDto,this.token).subscribe(x=>{
        this.assets=x
        this.dataSource = new MatTableDataSource(this.assets);
        this.dataSource.sort = this.sort
        this.dataSource.paginator = this.paginator;
      })
    }
    else{
      this._adminService.searchAllAssetByNameOrCategory(this.searchAssetDto,this.token).subscribe(x=>{
        this.assets=x
        this.dataSource = new MatTableDataSource(this.assets);
        this.dataSource.sort = this.sort
        this.dataSource.paginator = this.paginator;
    })
    }
  }

}
