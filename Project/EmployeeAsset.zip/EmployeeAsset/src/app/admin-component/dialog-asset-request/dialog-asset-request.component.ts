import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { AllocatedAssetDto } from '../../class/allocated-asset-dto';

@Component({
  selector: 'app-dialog-asset-request',
  templateUrl: './dialog-asset-request.component.html',
  styleUrl: './dialog-asset-request.component.css'
})
export class DialogAssetRequestComponent {

  constructor(private _dialogRef:MatDialogRef<DialogAssetRequestComponent>,@Inject(MAT_DIALOG_DATA) public asset: AllocatedAssetDto
){

  }


}
