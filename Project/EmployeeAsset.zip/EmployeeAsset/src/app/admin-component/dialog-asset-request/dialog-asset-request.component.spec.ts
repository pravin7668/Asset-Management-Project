import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogAssetRequestComponent } from './dialog-asset-request.component';

describe('DialogAssetRequestComponent', () => {
  let component: DialogAssetRequestComponent;
  let fixture: ComponentFixture<DialogAssetRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DialogAssetRequestComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DialogAssetRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
