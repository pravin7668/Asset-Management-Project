import { Component } from '@angular/core';
import { AdminService } from '../../service/admin.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Asset } from '../../class/asset';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-update-asset',
  templateUrl: './update-asset.component.html',
  styleUrl: './update-asset.component.css'
})
export class UpdateAssetComponent {
  assetId:number
  updatedAsset:Asset
  isValid:boolean
  categoryOptions: string[]
  statusOptions:string[]=["Available","Issued"]
  token:string

  constructor(private _adminService:AdminService,private _router:Router,private _activatedRoute:ActivatedRoute,private _toastr:ToastrService){
    this.updatedAsset=new Asset()
    this.token= localStorage.getItem("token")
    this._adminService.getAssetCategory(this.token).subscribe(x=>{
      this.categoryOptions=x      
    })
    this.isValid=false
  }
  ngOnInit():void{
    this._activatedRoute.queryParams.subscribe(param=>{
        this.updatedAsset.assetId=param['assetId'],
        this.updatedAsset.assetName=param['assetName'],
        this.updatedAsset.assetCategory=param['assetCategory'],
        this.updatedAsset.assetModel=param['assetModel'],
        this.updatedAsset.assetDescription=param['assetDescription'],
        this.updatedAsset.assetValue=param['assetValue'],
        this.updatedAsset.manufacturingDate=param['manufacturingDate'],
        this.updatedAsset.expiryDate=param['expiryDate'],
        this.updatedAsset.status=param['status']
        this.updatedAsset.imageUrl=param['imageUrl']


    })
  }
  res:string
  handleUpdate(){

    this._adminService.updateAsset(this.updatedAsset,this.token).subscribe(x=>{
      this.res=x
      // alert(this.res)
      this._toastr.success(this.res,'Success')

      this._router.navigate(['/admin-menu',{outlets:{'admin':['show-asset-with-search']}}])

    })
  }

  


}
