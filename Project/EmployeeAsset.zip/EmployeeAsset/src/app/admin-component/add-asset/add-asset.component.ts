import { Component } from '@angular/core';
import { AdminService } from '../../service/admin.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Asset } from '../../class/asset';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-asset',
  templateUrl: './add-asset.component.html',
  styleUrl: './add-asset.component.css'
})
export class AddAssetComponent {

  assetId:number
  updatedAsset:Asset
  isValid:boolean
  categoryOptions: string[]
  statusOptions:string[]=["Available","Issued"]
  token:string

  constructor(private _adminService:AdminService,private _router:Router,private _activatedRoute:ActivatedRoute,private _toastr:ToastrService){
    this.updatedAsset=new Asset()
    this.token= localStorage.getItem("token")
    this._adminService.getAssetCategory(this.token).subscribe(x=>{
      this.categoryOptions=x      
    })
    this.isValid=false
  }

  res:string
  handleAddAsset(loginForm:NgForm){
    this.isValid=false
    if(loginForm.invalid){
      return
    }
    this.isValid=true
    this._adminService.addAsset(this.updatedAsset,this.token).subscribe(x=>{
      this.res=x
      this._toastr.success(this.res,'Success')
      this._router.navigate(['/admin-menu',{outlets:{'admin':['show-asset-with-search']}}])

    })

  }



}
