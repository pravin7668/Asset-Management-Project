import { Component, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { PendingAssetRequest } from '../pending-asset-request/pending-asset-request.component';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { AdminService } from '../../service/admin.service';
import { SearchAssetAllocatedToUser } from '../../class/search-asset-allocated-to-user';
import { ToastrService } from 'ngx-toastr';

export type PendingServiceRequest={
    serviceId:number
    userId:number
    firstName:string
    assetId:number
    assetName:string
    serviceType:string
    description:string
    status:string
    assetDescription:string
    imageUrl:string
}

@Component({
  selector: 'app-pending-service-request',
  templateUrl: './pending-service-request.component.html',
  styleUrl: './pending-service-request.component.css'
})
export class PendingServiceRequestComponent {
  userAssets:PendingServiceRequest[]
  token:string
  adminId:number
  userSearch :SearchAssetAllocatedToUser
  userIdSearch:number
  inputType:string
  displayedColumns: string[] = [
    'userId',
    'firstName',
    'assetId',
    'assetName',
    'serviceType',
    'description',
    'status',
    'serviceButton'
  
  ];
  noData:boolean
  dataSource=new MatTableDataSource<PendingServiceRequest>
  @ViewChild(MatSort) sort = {} as MatSort;
  @ViewChild(MatPaginator) paginator = {} as MatPaginator;
  constructor(private _adminService:AdminService,private _toastr:ToastrService){
    this.userSearch=new SearchAssetAllocatedToUser()
    this.noData=false
      this.token=localStorage.getItem("token")
      this._adminService.showPendingServiceRequest(this.token).subscribe(x=>{
        this.userAssets=x
        if(this.userAssets.length==0){
          this.noData=true
        }
        this.dataSource = new MatTableDataSource(this.userAssets);
      this.dataSource.sort = this.sort
      this.dataSource.paginator = this.paginator;
      })
  }
  res:string
  handleService(serviceId:number){
    this.adminId=parseInt(localStorage.getItem("id"))
    this._adminService.approveAssetServiceRequest(this.adminId,serviceId,this.token).subscribe(x=>{
        this.res=x
        this._toastr.success(this.res,'Success')
        this._adminService.showPendingServiceRequest(this.token).subscribe(x=>{
          this.userAssets=x
          if(this.userAssets.length==0){
            this.noData=true
          }
          this.dataSource = new MatTableDataSource(this.userAssets);
        this.dataSource.sort = this.sort
        this.dataSource.paginator = this.paginator;
        })
    })
  }

  handleChange(){
    this.checkInputType(this.userSearch.inputFromAngular)
    if(this.userSearch.inputFromAngular==""){
      this._adminService.showPendingServiceRequest(this.token).subscribe(x=>{
        this.userAssets=x
        this.dataSource=new MatTableDataSource(this.userAssets)
        this.dataSource.paginator=this.paginator
        this.dataSource.sort=this.sort
      })
    }
    else if(this.inputType=="Integer"){
          this.userIdSearch=parseInt(this.userSearch.inputFromAngular)
          this._adminService.searchAssetServiceRequestByUserId(this.userSearch,this.token).subscribe(x=>{
            this.userAssets=x
            this.dataSource=new MatTableDataSource(this.userAssets)
            this.dataSource.paginator=this.paginator
            this.dataSource.sort=this.sort
          })

        }else{
          this._adminService.searchAssetServiceRequestByNameAndEmail(this.userSearch,this.token).subscribe(x=>{
            this.userAssets=x
            this.dataSource=new MatTableDataSource(this.userAssets)
            this.dataSource.paginator=this.paginator
            this.dataSource.sort=this.sort
          })
        }
  }

  checkInputType(value: string): void {
    const parsedValue = parseInt(value);

    if (Number.isInteger(parsedValue)) {
      this.inputType = 'Integer';
    } else {
      this.inputType = 'String';
    }
  }
}
