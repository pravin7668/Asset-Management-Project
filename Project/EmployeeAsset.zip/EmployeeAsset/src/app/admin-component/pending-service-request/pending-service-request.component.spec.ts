import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingServiceRequestComponent } from './pending-service-request.component';

describe('PendingServiceRequestComponent', () => {
  let component: PendingServiceRequestComponent;
  let fixture: ComponentFixture<PendingServiceRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PendingServiceRequestComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PendingServiceRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
