import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingServiceRequestCardComponent } from './pending-service-request-card.component';

describe('PendingServiceRequestCardComponent', () => {
  let component: PendingServiceRequestCardComponent;
  let fixture: ComponentFixture<PendingServiceRequestCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PendingServiceRequestCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PendingServiceRequestCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
