import { Component, EventEmitter, Input, Output } from '@angular/core';
import { PendingServiceRequest, PendingServiceRequestComponent } from '../pending-service-request/pending-service-request.component';

@Component({
  selector: 'app-pending-service-request-card',
  templateUrl: './pending-service-request-card.component.html',
  styleUrl: './pending-service-request-card.component.css'
})
export class PendingServiceRequestCardComponent {
  @Input() asset:PendingServiceRequest
  @Output() approveClicked=new EventEmitter<PendingServiceRequest>
  
  onApproveClick(){
    this.approveClicked.emit(this.asset)
  }
}
