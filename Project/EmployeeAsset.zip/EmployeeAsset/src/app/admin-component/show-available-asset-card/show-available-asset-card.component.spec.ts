import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAvailableAssetCardComponent } from './show-available-asset-card.component';

describe('ShowAvailableAssetCardComponent', () => {
  let component: ShowAvailableAssetCardComponent;
  let fixture: ComponentFixture<ShowAvailableAssetCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ShowAvailableAssetCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowAvailableAssetCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
