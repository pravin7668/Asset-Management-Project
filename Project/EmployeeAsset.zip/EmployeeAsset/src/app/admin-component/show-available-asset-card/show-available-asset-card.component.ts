import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Asset } from '../../class/asset';

@Component({
  selector: 'app-show-available-asset-card',
  templateUrl: './show-available-asset-card.component.html',
  styleUrl: './show-available-asset-card.component.css'
})
export class ShowAvailableAssetCardComponent {
  @Input() asset:Asset
  @Output() approveClicked=new EventEmitter<Asset>

  onApproveClick(){
    this.approveClicked.emit(this.asset)
  }
}
