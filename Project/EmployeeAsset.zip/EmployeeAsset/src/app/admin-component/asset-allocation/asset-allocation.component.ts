import { Component, ViewChild } from '@angular/core';
import { AllocatedAssetDto } from '../../class/allocated-asset-dto';
import { AdminService } from '../../service/admin.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { SearchAssetAllocatedToUser } from '../../class/search-asset-allocated-to-user';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
import { DialogAssetRequestComponent } from '../dialog-asset-request/dialog-asset-request.component';

@Component({
  selector: 'app-asset-allocation',
  templateUrl: './asset-allocation.component.html',
  styleUrl: './asset-allocation.component.css'
})
export class AssetAllocationComponent {
    displayedColumns:string[]=[
      'assetId',
      'assetName',
      'userId',
      'firstName',
      'issuedDate',
      'auditAssetButton'
    ]
    userAssets:AllocatedAssetDto[]
    userSearch :SearchAssetAllocatedToUser
    userId:number
    inputType:string
    name:string
    token:string
    dataSource=new MatTableDataSource<AllocatedAssetDto>
    @ViewChild(MatSort) sort={} as MatSort
    @ViewChild(MatPaginator) paginator={} as MatPaginator
    constructor(private _adminService:AdminService,private _toastr:ToastrService,private _dialog:MatDialog){
      this.userSearch=new SearchAssetAllocatedToUser()
      this.token=localStorage.getItem("token")
      this._adminService.showAssetAllocatedToUser(this.token).subscribe(x=>{
        this.userAssets=x
        this.dataSource=new MatTableDataSource(this.userAssets)
        this.dataSource.paginator=this.paginator
        this.dataSource.sort=this.sort
      })
    }

    handleChange(){
      this.checkInputType(this.userSearch.inputFromAngular)
      if(this.userSearch.inputFromAngular==""){
        this._adminService.showAssetAllocatedToUser(this.token).subscribe(x=>{
          this.userAssets=x
          this.dataSource=new MatTableDataSource(this.userAssets)
          this.dataSource.paginator=this.paginator
          this.dataSource.sort=this.sort
        })
      }
      else if(this.inputType=="Integer"){
            this.userId=parseInt(this.userSearch.inputFromAngular)
            this._adminService.searchshowAssetAllocatedToUserById(this.userSearch,this.token).subscribe(x=>{
              this.userAssets=x
              this.dataSource=new MatTableDataSource(this.userAssets)
              this.dataSource.paginator=this.paginator
              this.dataSource.sort=this.sort
            })

          }else{
            this._adminService.searchshowAssetAllocatedToUserByNameAndEmail(this.userSearch,this.token).subscribe(x=>{
              this.userAssets=x
              this.dataSource=new MatTableDataSource(this.userAssets)
              this.dataSource.paginator=this.paginator
              this.dataSource.sort=this.sort
            })
          }
    }

    checkInputType(value: string): void {
      const parsedValue = parseInt(value);
  
      if (Number.isInteger(parsedValue)) {
        this.inputType = 'Integer';
      } else {
        this.inputType = 'String';
      }
    }

    res:string
    handleAuditAsset(requestId:number){
        this._adminService.sendAuditRequest(requestId,this.token).subscribe(x=>{
          this._toastr.success(x,'Success')
        })
    }

    handleClick(asset:AllocatedAssetDto){
        this._dialog.open(DialogAssetRequestComponent,{
          width:'600px',
          height:'400px',
          data:asset
        })
    }
}
