import { Component } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { AdminService } from '../../service/admin.service';
import { Router } from '@angular/router';
import { Login } from '../../class/login';
import { LoginDto } from '../../class/login-dto';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
import { AdminSignupComponent } from '../admin-signup/admin-signup.component';
import { AdminForgotPasswordComponent } from '../admin-forgot-password/admin-forgot-password.component';
import { Admin } from '../../class/admin';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrl: './admin-login.component.css'
})
export class AdminLoginComponent {
  email:string
  password:string
  isValid:boolean
  credentials:Login
  loginDto:LoginDto
  userId:number
  user:Admin
  loginForm:FormGroup
  token:string
  userName:string
//   this._adminService.findAdminById1(this.credentials.userId).subscribe(xxx=>{
//     this.admin=xxx
//     console.log(this.admin)
//     localStorage.setItem("name",this.admin.firstName)

// })


  constructor(private _adminService:AdminService,private _router:Router,private _toastr:ToastrService,
    private _dialog:MatDialog,private _formBuilder:FormBuilder
  ){
    this.isValid=false
    this.loginDto=new LoginDto()
  }

  ngOnInit(){
    this.loginForm=this._formBuilder.group({
      'email':['',[Validators.required,Validators.email]],
      'password':['',Validators.required]
    })

    this.loginForm.get('email').statusChanges.subscribe(value=>{
      if(value=="VALID"){
        console.log(this.loginForm.get('email').value)
        this._adminService.findByEmail(this.loginForm.get('email').value).subscribe(xx=>{
          this.credentials=xx
          if(this.credentials!=null){
            this.userId=this.credentials.userId
            localStorage.setItem("id",this.credentials.userId.toString())
            this._adminService.findAdminById1(this.userId).subscribe(xxx=>{
                this.user=xxx
                this.userName=this.user.firstName
                localStorage.setItem("name",this.userName)
                console.log(this.userName)
            })
          }
        })
      }
    })
  }
  handleClick(){
    const _dialogRef= this._dialog.open(AdminSignupComponent,{
      width:'800px',
      height:'100vh'
   })
    // this._router.navigate(['admin-signup'])
  }
  handleLogin(){
    if(this.loginForm.valid){

      this.loginDto.email=this.loginForm.get('email').value
      this.loginDto.password=this.loginForm.get('password').value
      this._adminService.loginAdmin(this.loginDto).subscribe(x=>{
          this.token=x
          localStorage.setItem("token",this.token)
          this._router.navigate(['/admin-menu',{outlets:{'admin':['admin-dashboard']}}])
      })
    }
    else{
      this._toastr.error("Please Fill the Required Field","Error")
      this.loginForm.markAllAsTouched()
    }
    // this.isValid=false
    // if(loginForm.invalid){
    //   this._toastr.error("Please Fill the Required Field","Error")
    //   return

    // }
    // this.loginDto.email=this.email
    // this.loginDto.password=this.password
    // this.isValid=true
    // this._adminService.loginAdmin(this.loginDto).subscribe(x=>{
    //     localStorage.setItem("token",x)
    //     this._adminService.findByEmail(this.email).subscribe(xx=>{
    //       this.credentials=xx
    //       console.log(this.credentials)
    //       localStorage.setItem("id",this.credentials.userId.toString())


    //     })
    //     this._router.navigate(['/admin-menu',{outlets:{'admin':['admin-dashboard']}}])
    // })

  }

  handleForgotPassword(){
    const _dialogRef= this._dialog.open(AdminForgotPasswordComponent,{
      width:'800px',
      height:'500px'
   })
    // this._router.navigate(['admin-forgot-password'])
  }
}
