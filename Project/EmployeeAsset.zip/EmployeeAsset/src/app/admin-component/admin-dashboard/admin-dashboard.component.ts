import { Component } from '@angular/core';
import { PendingAssetRequest } from '../pending-asset-request/pending-asset-request.component';
import { PendingReturnRequest } from '../show-return-asset-request/show-return-asset-request.component';
import { AllocatedAssetDto } from '../../class/allocated-asset-dto';
import { PendingServiceRequestComponent } from '../pending-service-request/pending-service-request.component';
import { AdminService } from '../../service/admin.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css'
})
export class AdminDashboardComponent {
  pendingAssetRequest:PendingAssetRequest[]
  pendingReturnRequest:PendingReturnRequest[]
  pendingAuditRequest:AllocatedAssetDto[]
  pendingServiceRequest:PendingServiceRequestComponent[]

  noOfPendingAssetRequest:number
  noOfPendingReturnRequest:number
  noOfPendingAuditRequest:number
  noOfPendingServiceRequest:number

  token:string

  constructor(private _adminService:AdminService){
    this.token=localStorage.getItem("token")
    this._adminService.showPendingAuditRequest(this.token).subscribe(x=>{
      this.noOfPendingAuditRequest=x.length
    })

    this._adminService.showPendingAssetRequest(this.token).subscribe(x=>{
      this.noOfPendingAssetRequest=x.length
    })

    this._adminService.showPendingServiceRequest(this.token).subscribe(x=>{
      this.noOfPendingServiceRequest=x.length
    })

    this._adminService.showPendingReturnRequest(this.token).subscribe(x=>{
      this.noOfPendingReturnRequest=x.length
    })



  
  
  
 
 
  }




}
