import { Component, ViewChild, ViewEncapsulation } from '@angular/core';
import { Asset } from '../../class/asset';
import { AdminService } from '../../service/admin.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-asset',
  templateUrl: './show-asset.component.html',
  styleUrl: './show-asset.component.css',
})
export class ShowAssetComponent {
    selectedAsset:Asset[]=[]
    assets:Asset[]
    token:string
    displayedColumns: string[] = [
      'assetId',
      'assetName',
      'assetCategory',
      'assetDescription',
      'manufacturingDate',
      'expiryDate',
      'updateAssetButton'
    ];
    dataSource=new MatTableDataSource<Asset>
    @ViewChild(MatSort) sort = {} as MatSort;
    @ViewChild(MatPaginator) paginator = {} as MatPaginator;
    constructor(private _adminService:AdminService,private _router:Router){
        this.token=localStorage.getItem("token")

        this._adminService.showAsset(this.token).subscribe(x=>{
          this.assets=x
          this.selectedAsset=this.assets.slice(0,4)

          this.dataSource = new MatTableDataSource(this.assets);
        this.dataSource.sort = this.sort
        this.dataSource.paginator = this.paginator;
        })



    }

    handleAddAsset(){
        this._router.navigate(['/admin-menu',{outlets:{'admin':['add-asset']}}])
    }

    handleUpdateAsset(asset:Asset){
      this._router.navigate(['/admin-menu',{outlets:{'admin':['update-asset']}}],{queryParams:{
        assetId:asset.assetId,
        assetName:asset.assetName,
        assetCategory:asset.assetCategory,
        assetModel:asset.assetModel,
        assetDescription:asset.assetDescription,
        assetValue:asset.assetValue,
        manufacturingDate:asset.manufacturingDate,
        expiryDate:asset.expiryDate,
        status:asset.status,
        imageUrl:asset.imageUrl
      }})
    }
}
