import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AllocatedAssetDto } from '../../class/allocated-asset-dto';

@Component({
  selector: 'app-pending-asset-audit-card',
  templateUrl: './pending-asset-audit-card.component.html',
  styleUrl: './pending-asset-audit-card.component.css'
})
export class PendingAssetAuditCardComponent {
    @Input() asset:AllocatedAssetDto
    @Output() approveClicked=new EventEmitter<AllocatedAssetDto>

    onApproveClick(){
      this.approveClicked.emit(this.asset)
    }
}
