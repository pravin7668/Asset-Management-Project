import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingAssetAuditCardComponent } from './pending-asset-audit-card.component';

describe('PendingAssetAuditCardComponent', () => {
  let component: PendingAssetAuditCardComponent;
  let fixture: ComponentFixture<PendingAssetAuditCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PendingAssetAuditCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PendingAssetAuditCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
