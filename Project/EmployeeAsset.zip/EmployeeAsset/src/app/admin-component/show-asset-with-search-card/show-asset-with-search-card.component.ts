import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Asset } from '../../class/asset';

@Component({
  selector: 'app-show-asset-with-search-card',
  templateUrl: './show-asset-with-search-card.component.html',
  styleUrl: './show-asset-with-search-card.component.css'
})
export class ShowAssetWithSearchCardComponent {
  @Input() asset:Asset
  @Output() approveClicked=new EventEmitter<Asset>

  onApproveClick(){
    this.approveClicked.emit(this.asset)
  }
}
