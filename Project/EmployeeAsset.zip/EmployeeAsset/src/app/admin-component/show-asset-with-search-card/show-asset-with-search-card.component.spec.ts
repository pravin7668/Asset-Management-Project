import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAssetWithSearchCardComponent } from './show-asset-with-search-card.component';

describe('ShowAssetWithSearchCardComponent', () => {
  let component: ShowAssetWithSearchCardComponent;
  let fixture: ComponentFixture<ShowAssetWithSearchCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ShowAssetWithSearchCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowAssetWithSearchCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
