import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AllocatedAssetDto } from '../../class/allocated-asset-dto';

@Component({
  selector: 'app-asset-allocation-card',
  templateUrl: './asset-allocation-card.component.html',
  styleUrl: './asset-allocation-card.component.css'
})
export class AssetAllocationCardComponent {
  @Input() asset:AllocatedAssetDto
  @Output() approveClicked=new EventEmitter<AllocatedAssetDto>

  onApproveClick(){
    this.approveClicked.emit(this.asset)
  }
}
