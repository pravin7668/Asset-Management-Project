import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserComponent } from './user-component/user/user.component';
import {  HttpClientModule } from '@angular/common/http';
import { UserLoginComponent } from './user-component/user-login/user.login.component';
import { MenuComponent } from './menu/menu.component';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login-component.component';
import { ShowAvailableAssetComponent } from './admin-component/show-available-asset/show-available-asset.component';
import { ShowAssetComponent } from './admin-component/show-asset/show-asset.component';
import { AssetAllocationComponent } from './admin-component/asset-allocation/asset-allocation.component';
import { AdminMenuComponent } from './admin-menu/admin-menu.component';
import { AdminLoginComponent } from './admin-component/admin-login/admin-login.component';
import { UserAssetsComponent } from './user-component/user-assets/user-assets.component';
import { UserAssetsHistoryComponent } from './user-component/user-assets-history/user-assets-history.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatSortModule } from '@angular/material/sort';
import { UserSignupComponent } from './user-component/user-signup/user-signup.component';
import { AdminSignupComponent } from './admin-component/admin-signup/admin-signup.component';
import { RequestAssetComponent } from './user-component/request-asset/request-asset.component';
import { AssetRequestStatusComponent } from './user-component/asset-request-status/asset-request-status.component';
import { PendingAssetRequestComponent } from './admin-component/pending-asset-request/pending-asset-request.component';
import { ServiceRequestComponent } from './user-component/service-request/service-request.component';
import { PendingServiceRequestComponent } from './admin-component/pending-service-request/pending-service-request.component';
import { ReturnAssetComponent } from './user-component/return-asset/return-asset.component';
import { ShowReturnAssetRequestComponent } from './admin-component/show-return-asset-request/show-return-asset-request.component';
import { AddAssetComponent } from './admin-component/add-asset/add-asset.component';
import { UpdateAssetComponent } from './admin-component/update-asset/update-asset.component';
import { AuditRequestComponent } from './user-component/audit-request/audit-request.component';
import { PendingAssetAuditComponent } from './admin-component/pending-asset-audit/pending-asset-audit.component';
import { MatToolbar } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule } from '@angular/material/dialog';
import { MatMenuModule } from '@angular/material/menu';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatFormFieldModule } from '@angular/material/form-field';
import { TestComponent } from './test/test.component';
import { UserDashboardComponent } from './user-component/user-dashboard/user-dashboard.component';
import { ServiceRequestStatusComponent } from './user-component/service-request-status/service-request-status.component';
import { AdminDashboardComponent } from './admin-component/admin-dashboard/admin-dashboard.component';
import { AdminComponent } from './admin-component/admin/admin.component';
import { ShowAssetWithSearchComponent } from './admin-component/show-asset-with-search/show-asset-with-search.component';
import { AdminForgotPasswordComponent } from './admin-component/admin-forgot-password/admin-forgot-password.component';
import { UserForgotPasswordComponent } from './user-component/user-forgot-password/user-forgot-password.component';
import { authGuard } from './guard/auth.guard';
import { adminGuard } from './guard/admin.guard';
import { autoLoginGuard } from './guard/auto-login.guard';
import { AssetCardComponent } from './user-component/asset-card/asset-card.component';
import { AssetCardContainerComponent } from './user-component/asset-card-container/asset-card-container.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { RequestAssetCardComponent } from './user-component/request-asset-card/request-asset-card.component';
import { UserAssetHistoryCardComponent } from './user-component/user-asset-history-card/user-asset-history-card.component';
import { AssetRequestStatusCardComponent } from './user-component/asset-request-status-card/asset-request-status-card.component';
import { ServiceRequestStatusCardComponent } from './user-component/service-request-status-card/service-request-status-card.component';
import { AuditStatusCardComponent } from './user-component/audit-status-card/audit-status-card.component';
import { PendingAssetAuditCardComponent } from './admin-component/pending-asset-audit-card/pending-asset-audit-card.component';
import { PendingAssetRequestCardComponent } from './admin-component/pending-asset-request-card/pending-asset-request-card.component';
import { PendingServiceRequestCardComponent } from './admin-component/pending-service-request-card/pending-service-request-card.component';
import { ShowReturnRequestCardComponent } from './admin-component/show-return-request-card/show-return-request-card.component';
import { AssetAllocationCardComponent } from './admin-component/asset-allocation-card/asset-allocation-card.component';
import { ShowAvailableAssetCardComponent } from './admin-component/show-available-asset-card/show-available-asset-card.component';
import { ShowAssetWithSearchCardComponent } from './admin-component/show-asset-with-search-card/show-asset-with-search-card.component';
import { ShowAssetCardComponent } from './admin-component/show-asset-card/show-asset-card.component';
import { DialogAssetRequestComponent } from './admin-component/dialog-asset-request/dialog-asset-request.component';
import { UserUpdateComponent } from './user-component/user-update/user-update.component';
import { AdminUpdateComponent } from './admin-component/admin-update/admin-update.component';

const routes:Routes=[
  {path:'',component:LoginComponent,canActivate:[autoLoginGuard]},
  {path:'user-login',component:UserLoginComponent},
  {path:'user-forgot-password',component:UserForgotPasswordComponent},
  {path:'user-signup',component:UserSignupComponent},
  {path:'user-menu',component:MenuComponent,children:[
    {path:'user-show',component:UserComponent,outlet:'hexa',canActivate:[authGuard]},
    {path:'user-assets',component:AssetCardContainerComponent,outlet:'hexa',canActivate:[authGuard],children:[
      {path:'return-asset',component:ReturnAssetComponent,outlet:'hex'},
    ]},
    {path:'user-assets-history',component:UserAssetsHistoryComponent,outlet:'hexa',canActivate:[authGuard]},
    {path:'request-asset',component:RequestAssetComponent,outlet:'hexa',canActivate:[authGuard]},
    {path:'request-asset-status',component:AssetRequestStatusComponent,outlet:'hexa',canActivate:[authGuard]},
    {path:'service-request',component:ServiceRequestComponent,outlet:'hexa',canActivate:[authGuard]},
    {path:'audit-request',component:AuditRequestComponent,outlet:'hexa',canActivate:[authGuard]},
    {path:'user-dashboard',component:UserDashboardComponent,outlet:'hexa',canActivate:[authGuard]},
    {path:'service-request-status',component:ServiceRequestStatusComponent,outlet:'hexa',canActivate:[authGuard]},



  ]},
  // {path:'service-request',component:ServiceRequestComponent},
  {path:'admin-login',component:AdminLoginComponent},
  {path:'admin-forgot-password',component:AdminForgotPasswordComponent},
  {path:'admin-signup',component:AdminSignupComponent},
  {path:'admin-menu',component:AdminMenuComponent,children:[
    {path:'admin-show',component:AdminComponent,outlet:'admin',canActivate:[adminGuard]},
    {path:'show-asset',component:ShowAssetComponent,outlet:'admin',canActivate:[adminGuard]},
    {path:'show-asset-with-search',component:ShowAssetWithSearchComponent,outlet:'admin',canActivate:[adminGuard]},
    {path:'show-available-asset',component:ShowAvailableAssetComponent,outlet:'admin',canActivate:[adminGuard]},
    {path:'asset-allocated',component:AssetAllocationComponent,outlet:'admin',canActivate:[adminGuard]},
    {path:'pending-asset-request',component:PendingAssetRequestComponent,outlet:'admin',canActivate:[adminGuard]},
    {path:'pending-service-request',component:PendingServiceRequestComponent,outlet:'admin',canActivate:[adminGuard]},
    {path:'pending-return-request',component:ShowReturnAssetRequestComponent,outlet:'admin',canActivate:[adminGuard]},
    {path:'add-asset',component:AddAssetComponent,outlet:'admin',canActivate:[adminGuard]},
    {path:'update-asset',component:UpdateAssetComponent,outlet:'admin',canActivate:[adminGuard]},
    {path:'pending-audit-request',component:PendingAssetAuditComponent,outlet:'admin',canActivate:[adminGuard]},
    {path:'admin-dashboard',component:AdminDashboardComponent,outlet:'admin',canActivate:[adminGuard]},


    
  ]}

]

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    UserLoginComponent,
    MenuComponent,
    LoginComponent,
    ShowAvailableAssetComponent,
    ShowAssetComponent,
    AssetAllocationComponent,
    AdminMenuComponent,
    AdminLoginComponent,
    UserAssetsComponent,
    UserAssetsHistoryComponent,
    UserSignupComponent,
    AdminSignupComponent,
    RequestAssetComponent,
    AssetRequestStatusComponent,
    PendingAssetRequestComponent,
    ServiceRequestComponent,
    PendingServiceRequestComponent,
    ShowReturnAssetRequestComponent,
    AddAssetComponent,
    UpdateAssetComponent,
    AuditRequestComponent,
    PendingAssetAuditComponent,
    TestComponent,
    UserDashboardComponent,
    ServiceRequestStatusComponent,
    AdminDashboardComponent,
    AdminComponent,
    ShowAssetWithSearchComponent,
    AdminForgotPasswordComponent,
    UserForgotPasswordComponent,
    AssetCardComponent,
    AssetCardContainerComponent,
    RequestAssetCardComponent,
    UserAssetHistoryCardComponent,
    AssetRequestStatusCardComponent,
    ServiceRequestStatusCardComponent,
    AuditStatusCardComponent,
    PendingAssetAuditCardComponent,
    PendingAssetRequestCardComponent,
    PendingServiceRequestCardComponent,
    ShowReturnRequestCardComponent,
    AssetAllocationCardComponent,
    ShowAvailableAssetCardComponent,
    ShowAssetWithSearchCardComponent,
    ShowAssetCardComponent,
    DialogAssetRequestComponent,
    UserUpdateComponent,
    AdminUpdateComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatTableModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatCardModule,
    MatSortModule,
    MatToolbar,
    MatButtonModule,
    MatCheckboxModule,
    MatIconModule,
    MatDialogModule,
    MatMenuModule,
    MatSidenavModule,
    MatListModule,
    MatFormFieldModule,
    MatSelectModule,
    MatSidenavModule,
    RouterModule.forRoot(routes),
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      positionClass: 'toast-top-right', 
      preventDuplicates: true,
      progressBar: true,        
      progressAnimation: 'decreasing',
      timeOut:3000
    })

  
  ],
  providers: [
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
