export class ServiceRequestDto {
    requestId:number
    serviceType:string
    description:string
    constructor(){
        
    }
}
