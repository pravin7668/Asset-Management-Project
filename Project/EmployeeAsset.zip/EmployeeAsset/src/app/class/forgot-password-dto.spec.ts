import { ForgotPasswordDto } from './forgot-password-dto';

describe('ForgotPasswordDto', () => {
  it('should create an instance', () => {
    expect(new ForgotPasswordDto()).toBeTruthy();
  });
});
