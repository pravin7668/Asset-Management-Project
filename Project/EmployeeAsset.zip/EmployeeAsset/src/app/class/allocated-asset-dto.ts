export class AllocatedAssetDto {
    public  requestId:number
	public  adminId:number
	public  userId:number
	public  firstName:string
	public  assetId:number
	public  assetName:string
	public issuedDate:string
	public requestType:string
	public status:string
	public auditStatus:string
	public imageUrl:string
	public assetDescription:string
    constructor(){
        
    }

}
