import { MailHeaders } from './mail-headers';

describe('MailHeaders', () => {
  it('should create an instance', () => {
    expect(new MailHeaders()).toBeTruthy();
  });
});
