export class AssetServiceRequestDto {
    public serviceId:number
    public userId:number
    public firstName:string
    public assetId:number
    public assetName:string
    public serviceType:string
    public description:string
    public status:string
    public assetDescription:string
    public imageUrl:string
    constructor(){
        
    }
}
