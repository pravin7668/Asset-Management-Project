import { AssetHistoryDto } from './asset-history-dto';

describe('AssetHistoryDto', () => {
  it('should create an instance', () => {
    expect(new AssetHistoryDto()).toBeTruthy();
  });
});
