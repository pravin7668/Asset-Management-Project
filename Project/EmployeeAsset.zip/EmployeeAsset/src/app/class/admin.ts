export class Admin {
    public adminId:number
    public firstName:string
    public lastName:string
    public phoneno:string
    public address:string
    public email:string
    public password:string
    public status:string
    constructor(){
        
    }
}
