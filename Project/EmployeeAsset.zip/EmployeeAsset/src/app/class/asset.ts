export class Asset {

    public assetId:number
    public assetName:number
    public assetCategory:string
    public assetModel:string
    public assetDescription:string
    public assetValue:number
    public manufacturingDate:string
    public expiryDate:string
    public imageUrl:string
    public status:string
    constructor(){
        
    }

}
