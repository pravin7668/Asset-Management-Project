export class Login {
    public userId:number
    public email:string
    public password:string
    public role:string
    constructor(){
        
    }
}
