export class SearchAssetAllocatedToUser {
    public inputFromAngular:string
    constructor(){
        
    }
}
