import { SearchAssetAllocatedToUser } from './search-asset-allocated-to-user';

describe('SearchAssetAllocatedToUser', () => {
  it('should create an instance', () => {
    expect(new SearchAssetAllocatedToUser()).toBeTruthy();
  });
});
