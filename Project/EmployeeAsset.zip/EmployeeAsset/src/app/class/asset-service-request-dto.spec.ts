import { AssetServiceRequestDto } from './asset-service-request-dto';

describe('AssetServiceRequestDto', () => {
  it('should create an instance', () => {
    expect(new AssetServiceRequestDto()).toBeTruthy();
  });
});
