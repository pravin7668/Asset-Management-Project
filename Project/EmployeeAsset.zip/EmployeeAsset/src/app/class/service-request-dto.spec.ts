import { ServiceRequestDto } from './service-request-dto';

describe('ServiceRequestDto', () => {
  it('should create an instance', () => {
    expect(new ServiceRequestDto()).toBeTruthy();
  });
});
