export class AssetHistoryDto {
    public assetName:string
    public assetCategory:string
    public issuedDate:string
    public returnedDate:string
    public status:string
    public imageUrl:string
    public assetDescription:string
    constructor(){
        
    }
}
