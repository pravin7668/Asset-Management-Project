export class ForgotPasswordDto {
    public email:string
    public newPassword:string
    constructor(){
        
    }
}
