import { AssetRequestDto } from './asset-request-dto';

describe('AssetRequestDto', () => {
  it('should create an instance', () => {
    expect(new AssetRequestDto()).toBeTruthy();
  });
});
