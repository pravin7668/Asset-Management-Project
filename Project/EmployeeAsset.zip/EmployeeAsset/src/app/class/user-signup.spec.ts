import { UserSignup } from './user-signup';

describe('UserSignup', () => {
  it('should create an instance', () => {
    expect(new UserSignup()).toBeTruthy();
  });
});
