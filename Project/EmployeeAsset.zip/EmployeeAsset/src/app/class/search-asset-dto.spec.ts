import { SearchAssetDto } from './search-asset-dto';

describe('SearchAssetDto', () => {
  it('should create an instance', () => {
    expect(new SearchAssetDto()).toBeTruthy();
  });
});
