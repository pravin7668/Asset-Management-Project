import { Asset } from './asset';

describe('Asset', () => {
  it('should create an instance', () => {
    expect(new Asset()).toBeTruthy();
  });
});
