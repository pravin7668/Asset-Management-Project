import { AllocatedAssetDto } from './allocated-asset-dto';

describe('AllocatedAssetDto', () => {
  it('should create an instance', () => {
    expect(new AllocatedAssetDto()).toBeTruthy();
  });
});
