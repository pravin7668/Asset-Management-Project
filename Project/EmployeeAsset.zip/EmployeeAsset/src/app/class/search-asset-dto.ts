export class SearchAssetDto {
    assetName:string
    category:string
    constructor(){
        
    }
}
