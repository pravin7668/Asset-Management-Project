export class MailHeaders {
    public toEmail:string
    public subject:string
    public body:string
    constructor(){

    }
}
