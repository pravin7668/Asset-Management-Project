export class AssetRequestDto {
    public requestId:number 
    public userId:number
    public assetId:number
    public requestType:string
    public status:string
    constructor(){
        
    }

}
