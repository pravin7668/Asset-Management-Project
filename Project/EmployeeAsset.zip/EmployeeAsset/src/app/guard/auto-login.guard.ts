import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { JwtService } from '../service/jwt.service';

export const autoLoginGuard: CanActivateFn = (route, state) => {
  const _jwtService = inject(JwtService);
  const router = inject(Router);

  if (_jwtService.isLoggedIn()) {
    if(_jwtService.role()==="ROLE_Employee"){
      router.navigate(['/user-menu',{outlets:{'hexa':['user-dashboard']}}]);
      return true
    }
    else if(_jwtService.role()==="ROLE_Admin"){
      router.navigate(['/admin-menu',{outlets:{'admin':['admin-dashboard']}}])
      return true
    }
    else{
      return false
    }
  } else {
    return true
  }
};
