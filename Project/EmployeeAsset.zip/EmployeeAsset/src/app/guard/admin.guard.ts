import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { JwtService } from '../service/jwt.service';
import { ToastrService } from 'ngx-toastr';

export const adminGuard: CanActivateFn = (route, state) => {
  const _jwtService = inject(JwtService);
  const router = inject(Router);
  const _toastr=inject(ToastrService)

  if (_jwtService.isLoggedIn()) {
    if(_jwtService.role()==="ROLE_Admin"){
      return true;
    }
    else{
      alert("You are Not Authorized To Access Try User Login")
      router.navigate(['user-login']);
      return false
    }
  } else {
    _toastr.error("Credentials Expired Please Login Again",'Authentication Required',{
      timeOut:5000
    })
    router.navigate(['admin-login']);
    return false;
  }
};
