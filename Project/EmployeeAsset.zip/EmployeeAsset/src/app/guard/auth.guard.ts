import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../service/auth.service';
import { inject } from '@angular/core';
import { JwtService } from '../service/jwt.service';
import { ToastrService } from 'ngx-toastr';

export const authGuard: CanActivateFn = (route, state) => {
  const _jwtService = inject(JwtService);
  const router = inject(Router);
  const _toastr=inject(ToastrService)

  if (_jwtService.isLoggedIn()) {
    if(_jwtService.role()==="ROLE_Employee"){
      return true;
    }
    else{
      alert("You are Not Authorized Here Try Admin Login")
      router.navigate(['admin-login']);
      return false
    }
  } else {
    _toastr.error("Credentials Expired Please Login Again",'Authentication Required',{
      timeOut:5000
    })
    router.navigate(['user-login']);
    return false;
  }
};
