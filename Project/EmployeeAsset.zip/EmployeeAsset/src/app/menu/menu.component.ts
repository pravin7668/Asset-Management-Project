import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.css'
})
export class MenuComponent {
  isClicked:boolean
  userName:string
  constructor(private _router:Router){
      this.isClicked=false
      this.userName=localStorage.getItem("name")
  }
  logout(){
    localStorage.removeItem("id")
    localStorage.removeItem('token')
    this._router.navigate([''])
  }

  toggleWidth(){
      this.isClicked?this.isClicked=false:this.isClicked=true
      console.log(this.isClicked)
  }

}
