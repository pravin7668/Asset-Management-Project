package com.empasset.dto;

public class SearchAssetAllocatedToUser {
	private String inputFromAngular;

	public String getInputFromAngular() {
		return inputFromAngular;
	}

	public void setInputFromAngular(String inputFromAngular) {
		this.inputFromAngular = inputFromAngular;
	}
	

}
