package com.empasset.dto;

public class SearchAssetDto {
	private String assetName;
	private String category;
	public SearchAssetDto() {
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	

}
